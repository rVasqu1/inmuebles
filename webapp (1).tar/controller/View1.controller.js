sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    "use strict";
var aux;
var factCanonModel;
    return Controller.extend("project1.controller.View1", {
        onInit() {
            var oData = {
                rows: [
                  {
                    Bukrs: "Juan",
                    ZregeRefacturar: 30,
                    ZrefeFactaual: "Madrid",
                    ZrefeFActmes: "España",
                    ZrefeFActeset: "juan@example.com",
                    ZrefeFActacu: "600123456",
                    ZrefeFActpen: true,
                    ZregeYear: 2001,
                    Zmoneda: 200
                  },
                  {
                    Bukrs: "Juan",
                    ZregeRefacturar: 30,
                    ZrefeFactaual: "Madrid",
                    ZrefeFActmes: "España",
                    ZrefeFActeset: "juan@example.com",
                    ZrefeFActacu: "600123456",
                    ZrefeFActpen: 200,
                    ZregeYear: 2001,
                    Zmoneda: 200
                  },
                ]
              };

              factCanonModel = new sap.ui.model.json.JSONModel({}, true);
              factCanonModel.setData(oData)
			this.getView().setModel(factCanonModel, "factCanonModel");  


            aux = new sap.ui.model.json.JSONModel({
				procesado: false,
                visButton: true
			}, true);
			this.getView().setModel(aux, "aux");  


        },
        onGenerarPedido: function(oEvent){
            aux.setProperty("/procesado", true)
            aux.setProperty("/visButton", false)
        },
        onAddRow: function () {
            var oModel = this.getView().getModel("factCanonModel");
            var aRows = oModel.getProperty("/rows");
          
            // Fila vacía con los mismos campos que las existentes
            var oNewRow = {
              Bukrs: "",
              ZregeRefacturar: null,
              ZrefeFactaual: "",
              ZrefeFActmes: "",
              ZrefeFActeset: "",
              ZrefeFActacu: "",
              ZrefeFActpen: null,
              ZregeYear: null,
              Zmoneda: null
            };
          
            aRows.push(oNewRow);
            oModel.setProperty("/rows", aRows);
          }
    });
});