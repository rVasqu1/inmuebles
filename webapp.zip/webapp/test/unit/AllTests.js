sap.ui.define([
	"mapfrenet/zsd_monitorfact/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
