/* global QUnit */

sap.ui.require(["mapfre/net/zsdmonitorfact/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
