sap.ui.define([
    "sap/ui/core/mvc/Controller",
	"mapfre/net/zsdmonitorfact/utils/Utils",
	"mapfre/net/zsdmonitorfact/lib/xlsx.full.min",
	"sap/ui/export/Spreadsheet",
	"sap/ui/export/library",
], (Controller,Utils, xlsxLib, Spreadsheet, exportLibrary) => {
    "use strict";

	const EdmType = exportLibrary.EdmType;

    return Controller.extend("mapfre.net.zsdmonitorfact.controller.regularizacion", {
		onAfterRendering: function() {
			this.cesvimap = false;	
			this.proceso = null;
			this.mes = null;
			this.anio = null;		
            this.oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			
			var oTable =  this.byId("tableMonitorRegul");
			this.oTable = oTable;
			oTable.onAfterRendering = function() {
				sap.ui.table.Table.prototype.onAfterRendering.apply(this, arguments);
				
			  };

        },

		pintarLineaImporte : function(){
			var oTable = this.oTable;
				var aRows = oTable.getRows();
				if (aRows && aRows.length > 0) {
				//Filas que se deben borrar
				for(var iR in aRows ){
					//Agregamos el copiado en la columna de importe y texto adicional
					aRows[iR].getCells()[7].attachBrowserEvent("paste", function (e) {
						e.stopPropagation();
						
						e.preventDefault();
						var data = e.originalEvent.clipboardData.getData('text/plain');
						if(data){
							var rows = data.split("\r\n");
							for(var i in rows){
								var index = parseInt(this.getBindingContext("monitor").getPath().replace("/",""))+parseInt(i)
								var contextObj = (new sap.ui.model.Context(this.getBindingContext("monitor").getModel(),"/"+index)).getObject();
								if(contextObj){
									contextObj.ZregeTextadic = rows[i].split("\t")[0];
									
									if(rows[i].split("\t")[1]){
										contextObj.ZregeImporte = parseFloat(rows[i].split("\t")[1].replace(",","."));
									}
								}else{
									break;
								}
							}
							var oItemMonitor = this.getBindingContext("monitor").getObject();
							var aMonitor = this.getBindingContext("monitor").getModel().getData();
							Utils._recalcularItem(oItemMonitor,aMonitor,0,0);
							this.getBindingContext("monitor").getModel().refresh();	
						}

					});
					aRows[iR].getCells()[8].attachBrowserEvent("paste", function (e) {
						e.stopPropagation();
						
						e.preventDefault();
						var data = e.originalEvent.clipboardData.getData('text/plain');
						if(data){
							var rows = data.split("\r\n");
							for(var i in rows){
								var index = parseInt(this.getBindingContext("monitor").getPath().replace("/",""))+parseInt(i)
								var contextObj = (new sap.ui.model.Context(this.getBindingContext("monitor").getModel(),"/"+index)).getObject();
								if(contextObj){
									contextObj.ZregeImporte = parseFloat(rows[i].split("\t")[0].replace(",","."));
								}else{
									break;
								}
							}
							var oItemMonitor = this.getBindingContext("monitor").getObject();
							var aMonitor = this.getBindingContext("monitor").getModel().getData();
							Utils._recalcularItem(oItemMonitor,aMonitor,0,0);
							this.getBindingContext("monitor").getModel().refresh();	
						}

					});
				}
				  aRows.map((aRow, i) => {
						if(aRow.getBindingContext("monitor")){
							if(aRow.getBindingContext("monitor").getObject()._ultimoReg){
								for(var c in aRow.getCells()){
									$("#" + aRow.getCells()[c].getId()).parent().parent().css("border-bottom", "2px black solid");
								}
							}else{
								for(var c in aRow.getCells()){
									if(c != 4){
										$("#" + aRow.getCells()[c].getId()).parent().parent().css("border-bottom", ".0625rem solid #e5e5e5");
									}else{
										$("#" +aRow.getCells()[4].getId()).parent().parent().css("border-bottom-style", "hidden");
									}
								}
							}
							if(!aRow.getBindingContext("monitor").getObject()._visibleBI){
								$("#" + aRow.getCells()[4].getId()).css("display", "none");
							}else{
								$("#" + aRow.getCells()[4].getId()).css("display", "block");
								$("#" + aRow.getCells()[4].getId()).css("text-align", "right");
							}
						}  
					//}
					//pRow = aRow;
					
				  });
				  //oTable.rerender()
				}
		},

		updateFinished : function(){
			this.oTable.rerender()
		},

		rowsUpdated : function(){
			this.pintarLineaImporte();
		},
		
		onChangeImporte : function (oEvent){
			var oItemMonitor = oEvent.getSource().getBindingContext("monitor").getObject();
			var aMonitor = this.getView().getModel("monitor").getData();
			Utils._recalcularItem(oItemMonitor,aMonitor,0,0);
			oEvent.getSource().getBindingContext("monitor").getModel().refresh();

		},
		onChangeFechaFactura: function(oEvent){
			if(oEvent.getSource().getDateValue() < new Date() && oEvent.getSource().getDateValue().toLocaleDateString() != new Date().toLocaleDateString()){
				var oItemMonitor = oEvent.getSource().getBindingContext("monitor").getObject();
				oItemMonitor._statusFechaFactura = "Error";
				oItemMonitor._messageErrorFechaFactura = this.oResourceBundle.getText("fechaNoPuedeSerInferior")
			}else{
				var oItemMonitor = oEvent.getSource().getBindingContext("monitor").getObject();
				oItemMonitor._statusFechaFactura = "None";
				oItemMonitor._messageErrorFechaFactura = this.oResourceBundle.getText("fechaNoPuedeSerInferior")
			}
		},
		onSelectFacturar : function(oEvent){
			var oItemMonitor = oEvent.getSource().getBindingContext("monitor").getObject();
			var aMonitor = this.getView().getModel("monitor").getData();
			for(var i in aMonitor){
				if(aMonitor[i].ZsocEmisora == oItemMonitor.ZsocEmisora && aMonitor[i].ZsocReceptora == oItemMonitor.ZsocReceptora && aMonitor[i].ZregeIdfact == oItemMonitor.ZregeIdfact){
					aMonitor[i].ZregeEstado = oItemMonitor.ZregeEstado;
				}
			}
			oEvent.getSource().getBindingContext("monitor").getModel()
		},
		onCancelar : function(){
			Utils.cancelar.bind(this)();
		},
		onGenerarPedido : function(){
				var odata = jQuery.extend(true,[],this.getView().getModel("monitor").getData());
				for(var i in odata){
					for(var j in odata[i]){
						if(j.indexOf("_") === 0){
							odata[i][j] = undefined;
						}
					}
					odata[i].ZregeImporte = odata[i].ZregeImporte +""
					switch (odata[i].ZsocEmisora) {
						case '0002':
							odata[i].ZregeTipo = 'ZVOL'
							break;
						case '0003':
							odata[i].ZregeTipo = 'ZVOL'
							break;
						case 'Y051':
							odata[i].ZregeTipo = 'ZVOL'
							break;
						case '0073':
							odata[i].ZregeTipo = 'ZRED'
							break;
					}
				}	
				var item = {
					matnr: "",
					Zcanalemisor: "",
					Zcanalreceptor: "",
					Zcecoemisor: "",
					Zcecoreceptor: "",
					Zcodsreceptor: "",
					Zcuentareceptor: "",
					Zlnemisor: "",
					Zlnreceptor: "",
					ZregeExento: "",
					ZregeIdfact: "",
					ZregeRenuncia: "",
					ZregeServicio: "",
					ZsocEmisora: "",
					ZsocReceptora: "",
					Zmonitor:"",
					Zcsv:"",
					HeaderToItem: odata
					};
				this.getView().getModel().create("/Header_monfSet", item, {
                    success: function (oResult, oResponse) {
						var csvString = oResult.Zcsv;
						if(csvString){
							var arrayOfArrayCsv = csvString.split("\n").map(row => {
								return row.split(";")
							});
							var wb = XLSX.utils.book_new();
							var newWs = XLSX.utils.aoa_to_sheet(arrayOfArrayCsv);
							XLSX.utils.book_append_sheet(wb, newWs);
							var rawExcel = XLSX.write(wb, { type: 'base64' })
							this.getView().getModel().create("/xlsxSet",{string:rawExcel}, {
								success:function(){

								}
							})
						}
					}.bind(this),
                    error: function (oError) {
						debugger
					}
				});
 
		},
		formatMounth : function(mounth){
			return Utils.formatMounth.bind(this)(mounth);
		},
		downloadTable: function () {
			if (!this._oTable) {
				this._oTable = this.byId("tableMonitorRegul");
			}

			const oTable = this._oTable;
			const oRowBinding = oTable.getBinding("rows");
			const aCols = this.createColumnConfig(oTable.getColumns());
			var socEmisora = "";
			if(this.getView().getModel("monitor").getData().length > 0){
				socEmisora = this.getView().getModel("monitor").getData()[0].Emisor;
			}
			const oSettings = {
				workbook: {
					columns: aCols,
					hierarchyLevel: "Level"
				},
				dataSource: oRowBinding,
				fileName: this.oResourceBundle.getText("ficheroXlS") +' '+socEmisora + ".xlsx",
				worker: false // We need to disable worker because we are using a MockServer as OData Service
			};

			const oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function () {
				oSheet.destroy();
			});
		},
		createColumnConfig: function (columns) {
			const aCols = [];
			for (var i in columns) {
				if (columns[i].getTemplate().getBindingInfo("value") && columns[i].getTemplate().getBindingInfo("value").parts[0].path === "ZfechaFactura") {
					aCols.push({
						label: columns[i].getLabel().getText(),
						property: "ZfechaFactura",
						type: EdmType.Date
					});
				} else {
					aCols.push({
						label: columns[i].getLabel().getText(),
						property: columns[i].getTemplate().getBindingInfo("value") ? columns[i].getTemplate().getBindingInfo("value").parts[0].path : columns[i].getTemplate().getBindingInfo("text") ? columns[i].getTemplate().getBindingInfo("text").parts[0].path : columns[i].getTemplate().getBindingInfo("selectedKey") ? columns[i].getTemplate().getBindingInfo("selectedKey").parts[0].path : "",
						type: EdmType.String
					});
				}
			}
			return aCols;
		},
		onFileChange: function (oEvent) {
			var oFile = oEvent.getParameter("files")[0];

			var reader = new FileReader();

			reader.onload = function (e) {

				sap.ui.core.BusyIndicator.show();

				var data = e.target.result;
				var workbook = XLSX.read(data, {
					type: 'binary',
					cellDates: true
				});
				console.log(workbook)

				var oMessages = [];

				workbook.SheetNames.forEach(function (sheetName) {

					var XL_row_object =
						XLSX.utils.sheet_to_row_object_array(
							workbook.Sheets[sheetName]);
					if (XL_row_object.length !== 0) {

						var table = this.byId("tableMonitorRegul");
						var odata = this.getView().getModel("monitor").getData();
						var columns = table.getColumns();
						var index = 0
						XL_row_object.forEach(XL_row => {
							let service = {};
							var item = odata[index];
							index = index + 1;
							for (var i in columns) {
								var path = columns[i].getTemplate().getBindingInfo("value") ? columns[i].getTemplate().getBindingInfo("value").parts[0].path : columns[i].getTemplate().getBindingInfo("text") ? columns[i].getTemplate().getBindingInfo("text").parts[0].path : columns[i].getTemplate().getBindingInfo("selectedKey") ? columns[i].getTemplate().getBindingInfo("selectedKey").parts[0].path : ""
								service[path] = XL_row[columns[i].getLabel().getText()]?.toString() ?? "";
							}
							if (XL_row["F. facturación*"]) {
								XL_row["F. facturación*"] = XL_row["F. facturación*"].replaceAll ? this.parseFecha(XL_row["F. facturación*"]) :XL_row["F. facturación*"]; 
								var fechaFact = new Date(XL_row["F. facturación*"]);
								fechaFact = new Date(fechaFact.getTime() - (fechaFact.getTimezoneOffset() * 60 * 1000));
								service.ZfechaFactura = fechaFact;
							} else {
								service.ZfechaFactura = null;
							}
							item.ZregeTextadic = service.ZregeTextadic;
							item.ZregeImporte = service.ZregeImporte;
							item.ZregeEstado = service.ZregeEstado;
							item.ZfechaFactura = service.ZfechaFactura;

						});

					}

				}.bind(this))

				this.getView().getModel("monitor").refresh();

				if (oMessages.length === 0) {
					sap.ui.core.BusyIndicator.hide();
					jQuery.sap.delayedCall(100, this, function () {

					}.bind(this))
				} else {
					mensajes = this.armarMensajFront(mensajes);
					this.mostrarMensajes(mensajes, this);
					sap.ui.core.BusyIndicator.hide();
				}


			}.bind(this);

			reader.onerror = function (ex) {
				console.log(ex);
			};

			reader.readAsBinaryString(oFile);

		},
		parseFecha: function(fechaStr) {
			// Primero validamos el formato yyyy.mm.dd
			let match = fechaStr.match(/^(\d{4})\.(\d{2})\.(\d{2})$/);
			if (match) {
				const [_, year, month, day] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}

			// Validamos el formato yyyy/mm/dd
			match = fechaStr.match(/^(\d{4})\/(\d{2})\/(\d{2})$/);
			if (match) {
				const [_, year, month, day] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}
		
			// Luego validamos el formato dd.mm.yyyy
			match = fechaStr.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
			if (match) {
				const [_, day, month, year] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}

			// Luego validamos el formato dd-mm-yyyy
			match = fechaStr.match(/^(\d{2})\-(\d{2})\-(\d{4})$/);
			if (match) {
				const [_, day, month, year] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}

			// Luego validamos el formato yyyy-mm-dd
			match = fechaStr.match(/^(\d{4})\-(\d{2})\-(\d{2})$/);
			if (match) {
				const [_, year, month, day] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}
		
			return null; // No coincide con ninguno
		},
		armarMensajFront: function (mensaje) {
			var mensajes = [];

			if (mensaje.length) {
				for (var i = 0; i < mensaje.length; i++) {
					mensajes.push({
						"Type": mensaje[i].severity,
						"Message": mensaje[i].message,
						"Group": mensaje[i].group
					});
				}
			}
			return mensajes;
		},
		mostrarMensajes: function (mensajes, thes, callback) {


			/*var mensajes = [{
				"Type": "E",
				"Message": "Mensaje de prueba"
			}];*/

			for (var i = 0; i < mensajes.length; i++) {
				switch (mensajes[i].Type) {
					case "E":
						mensajes[i].Type = "Error";
						break;
					case "S":
						mensajes[i].Type = "Success";
						break;
					case "W":
						mensajes[i].Type = "Warning";
						break;
					case "I":
						mensajes[i].Type = "Information";
						break;
					case "error":
						mensajes[i].Type = "Error";
						break;
					case "success":
						mensajes[i].Type = "Success";
						break;
					case "warning":
						mensajes[i].Type = "Warning";
						break;
					case "info":
						mensajes[i].Type = "Information";
						break;
				}
			}

			var oMessageTemplate = new sap.m.MessageItem({
				type: '{Type}',
				title: '{Message}',
				groupName: '{Group}'
			});

			var oModel = new sap.ui.model.json.JSONModel(mensajes);

			var oBackButton = new sap.m.Button({
				icon: sap.ui.core.IconPool.getIconURI("nav-back"),
				visible: false,
				press: function () {
					thes.oMessageView.navigateBack();
					this.setVisible(false);
				}
			});

			this.oMessageView = new sap.m.MessageView({
				showDetailsPageHeader: false,
				itemSelect: function () {
					oBackButton.setVisible(true);
				},
				items: {
					path: "/",
					template: oMessageTemplate
				},
				groupItems: true
			});

			this.oMessageView.setModel(oModel);

			this.oDialog = new sap.m.Dialog({
				resizable: true,
				content: this.oMessageView,
				beginButton: new sap.m.Button({
					press: function (oEvent) {
						sap.ui.getCore().byId(oEvent.getSource().getParent().getId()).close();
					},
					text: "Close"
				}),
				customHeader: new sap.m.Bar({
					contentMiddle: [
						new sap.m.Text({
							text: "Mensajes"
						})
					],
					contentLeft: [oBackButton]
				}),
				contentHeight: "50%",
				contentWidth: "50%",
				verticalScrolling: false
			});
			if (callback) {
				this.oDialog.setBeginButton(new sap.m.Button({
					text: this.oResourceBundle.getText("continuar"),
					press: callback.bind(this)
				}))
			}

			this.oMessageView.navigateBack();
			this.oDialog.open();



		}
    });
});