sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"mapfre/net/zsdmonitorfact/utils/Utils",
	"mapfre/net/zsdmonitorfact/lib/xlsx.full.min",
	"sap/ui/export/Spreadsheet",
	"sap/ui/export/library",
], (Controller, Utils, xlsxLib, Spreadsheet, exportLibrary) => {
	"use strict";

	return Controller.extend("mapfre.net.zsdmonitorfact.controller.rectificacionImp", {
		onAfterRendering: function () {
			this.proceso = null;
			this.mes = null;
			this.anio = null;
			this.oResourceBundle = this.getView().getModel("i18n").getResourceBundle();

		},
		formatMounth: function (mounth) {
			return Utils.formatMounth.bind(this)(mounth);
		},
		rowsUpdated: function () {
			this.pintarLineaImporte();
		},
		pintarLineaImporte: function () {
			var oTable = this.getView().byId("tableMonitorRecFact");
			var aRows = oTable.getRows();
			if (aRows && aRows.length > 0) {
				aRows.map((aRow, i) => {
					if (aRow.getBindingContext("monitor")) {
						if (aRow.getBindingContext("monitor").getObject()._ultimoReg) {
							for (var c in aRow.getCells()) {
								$("#" + aRow.getCells()[c].getId()).parent().parent().css("border-bottom", "2px black solid");
							}
						} else {
							for (var c in aRow.getCells()) {
								if (c != 2) {
									$("#" + aRow.getCells()[c].getId()).parent().parent().css("border-bottom", ".0625rem solid #e5e5e5");
								} else {
									$("#" + aRow.getCells()[2].getId()).parent().parent().css("border-bottom-style", "hidden");
								}
							}
						}
						if (!aRow.getBindingContext("monitor").getObject()._visibleBI) {
							$("#" + aRow.getCells()[2].getId()).css("display", "none");
						} else {
							$("#" + aRow.getCells()[2].getId()).css("display", "block");
							$("#" + aRow.getCells()[2].getId()).css("text-align", "right");
						}
					}
				})
			}
		},

		onChangeImporte: function (oEvent) {
			var oItemMonitor = oEvent.getSource().getBindingContext("monitor").getObject();
			oItemMonitor.ZregeBinr = (parseFloat(oItemMonitor.ZregeImporte).toFixed(2) - oItemMonitor.ZregeHistBiapli).toFixed(2);
			oEvent.getSource().getBindingContext("monitor").getModel().refresh();

		},
		onChangeProcesar: function (oEvent) {
			var idFact = oEvent.getSource().getBindingContext("monitor").getObject().ZregeIdfact;
			var monitor = this.getView().getModel("monitor").getData();
			var selected = oEvent.getSource().getSelectedKey();
			for (var i in monitor) {
				if (monitor[i].ZregeIdfact === idFact) {
					monitor[i]._zregeproc = selected;
					for (var j in monitor) {
						if (monitor[j]._cloneId === i) {
							monitor[j]._zregeproc = selected;
							monitor[j].ZregeImporte = 0;
							break;
						}
					}
				}

			}
			this.getView().getModel("monitor").refresh();

		},
		onGenerarPedido: function () {
			var auxData = this.getView().getModel("aux").getData();
			var mes = auxData._mes;
			var anio = auxData._anio;
			var zsocemisora = "";
			var odata = jQuery.extend(true, [], this.getView().getModel("monitor").getData());
			var Array = []
			for (var i in odata) {
				if (odata[i]._zregeproc == 'SI') {
					odata[i].Zindex = "";
					if (odata[i]._original) {
						odata[i].Zinverso = "X";
						switch (odata[i].ZsocEmisora) {
							case '0002':
								odata[i].ZregeTipo = 'ZREC'
								break;
							case '0003':
								odata[i].ZregeTipo = 'ZREC'
								break;
							case 'Y051':
								odata[i].ZregeTipo = 'ZPFC'
								break;
							case '0073':
								odata[i].ZregeTipo = 'ZPFC'
								break;
						}
					}else{
						odata[i].ZregeTipo = 'ZAFC';
					}
					odata[i].ZregeImporte = odata[i].ZregeImporte + "";

					Array.push(odata[i]);
				}
				zsocemisora = odata[i].ZsocEmisora;
				odata[i].ZregeBinr = parseFloat(odata[i].ZregeBinr).toFixed(2)
				odata[i].ZregeHistBiapli = parseFloat(odata[i].ZregeHistBiapli).toFixed(2)
				odata[i].ZregeIva = parseFloat(odata[i].ZregeIva).toFixed(2)
				odata[i].ZregeImporte = parseFloat(odata[i].ZregeImporte).toFixed(2)
			}
			for (var i in odata) {
				for (var j in odata[i]) {
					if (j.indexOf("_") === 0) {
						odata[i][j] = undefined;
					}
				}
			}
			this.dialogWaitPedido = new sap.m.Dialog(
				{
					showHeader: false,
					content: [
						new sap.m.HBox({ justifyContent: "Center", alignItems: "Center", items: [new sap.m.BusyIndicator({ text: "{i18n>procesandoPedido}" })] })
					]
				}
			)
			this.getView().addDependent(this.dialogWaitPedido);
			this.dialogWaitPedido.open();
			var item = {
				matnr: "",
				Zcanalemisor: "",
				Zcanalreceptor: "",
				Zcecoemisor: "",
				Zcecoreceptor: "",
				Zcodsreceptor: "",
				Zcuentareceptor: "",
				Zlnemisor: "",
				Zlnreceptor: "",
				ZregeExento: "",
				ZregeIdfact: "",
				ZregeRenuncia: "",
				ZregeServicio: "",
				ZsocEmisora: "",
				ZsocReceptora: "",
				Zmonitor: "RECIMP",
				Zcsv: "",
				HeaderToItem: Array
			};
			var _filtroReceptores = auxData._filtroReceptores;
			this.getView().getModel().create("/Header_monfSet", item, {
				success: function (oResult, oResponse) {
					var csvString = oResult.Zcsv;
					/*if (csvString) {
						var arrayOfArrayCsv = csvString.split("\n").map(row => {
							return row.split(";")
						});
						var wb = XLSX.utils.book_new();
						var newWs = XLSX.utils.aoa_to_sheet(arrayOfArrayCsv);
						XLSX.utils.book_append_sheet(wb, newWs);
						var rawExcel = XLSX.write(wb, { type: 'base64' })
						this.getView().getModel().create("/xlsxSet", { string: rawExcel }, {
							success: function () {
								this.dialogWaitPedido.close();
							}.bind(this),
							error: function () {*/
								this.dialogWaitPedido.close();
								var aFilters = [];
								aFilters.push(new sap.ui.model.Filter("ZregeMes", "EQ", mes));
								aFilters.push(new sap.ui.model.Filter("ZregeEstado", "EQ", "SI"));
								aFilters.push(new sap.ui.model.Filter("ZregeHistMes", "EQ", mes))
								aFilters.push(new sap.ui.model.Filter("ZregeHistYear", "EQ", anio));
								aFilters.push(_filtroReceptores)
								this.getView().getModel().read("/ZCMSD_REGE_MONF", {
									filters: aFilters,
									success: function (oData) {
										this.showLog = true;
										auxData.showLog = true;
										this.getView().getModel("aux").refresh();
										var tableMonitor = oData.results;
										tableMonitor.sort((a, b) => {
											var nameA = a.ZsocEmisora + "|" + a.ZsocReceptora + "|" + a.ZregeBiapli;
											var nameB = b.ZsocEmisora + "|" + b.ZsocReceptora + "|" + b.ZregeBiapli;
											if (nameA < nameB) {
												return -1;
											}
											if (nameA > nameB) {
												return 1;
											}
											return 0;
										});

										if (tableMonitor.length > 1) {
											var biIguales = 1;
											for (var i = 1; i < tableMonitor.length; i++) {
												if (tableMonitor[i].ZsocReceptora !== tableMonitor[i - 1].ZsocReceptora ||
													tableMonitor[i].ZsocEmisora !== tableMonitor[i - 1].ZsocEmisora ||
													tableMonitor[i].ZregeBiapli !== tableMonitor[i - 1].ZregeBiapli) {
													tableMonitor[i - 1]._ultimoReg = true;
													tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
													biIguales = 1
													//Ultimo registro
													if (i == (tableMonitor.length - 1)) {
														tableMonitor[i]._ultimoReg = true;
														tableMonitor[i]._visibleBI = true;
													}
												} else {
													biIguales = biIguales + 1;
												}
											}
											if (biIguales > 1) {
												tableMonitor[i - 1]._ultimoReg = true;
												tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
												biIguales = 1
											}
										} else if (tableMonitor.length === 1) {
											tableMonitor[0]._ultimoReg = true;
											tableMonitor[0]._visibleBI = true;
										}
										this.getView().getModel("monitor").setData(tableMonitor);
									}.bind(this)
								});

							/*}.bind(this)
						})
					}*/
				}.bind(this),
				error: function (oError) {
					var mensajes = JSON.parse(oError.responseText).error.innererror.errordetails;
					mensajes = this.armarMensajFront(mensajes);
					this.mostrarMensajes(mensajes, this);
					this.dialogWaitPedido.close();
				}.bind(this)
			});
		},
		onCancelar: function () {
			Utils.cancelar.bind(this)();;
		},
	});
});