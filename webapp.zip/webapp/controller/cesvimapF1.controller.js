sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"mapfre/net/zsdmonitorfact/utils/Utils",
	"mapfre/net/zsdmonitorfact/lib/xlsx.full.min",
	"sap/ui/export/Spreadsheet",
	"sap/ui/export/library",
], (Controller, Utils, xlsxLib, Spreadsheet, exportLibrary) => {
	"use strict";

	const EdmType = exportLibrary.EdmType;

	return Controller.extend("mapfre.net.zsdmonitorfact.controller.cesvimapF1", {
		onAfterRendering: function () {
			var auxData = this.getView().getModel("aux").getData();
			if (!auxData._mes) {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("");
			}
			this.oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			var oContextCreateBI = this.getView().getModel().createEntry("/ZCMSD_REGE_MONF", {
				properties: {
					ZsocEmisora: "0073",
					ZregeMes:auxData._mes,
					ZregeYear: auxData._anio
				}
			})
			var oView = this.getView();
			this.jsonModelMonitor = new sap.ui.model.json.JSONModel([{ ZsocEmisora: "0073", _pathSmarfield: oContextCreateBI.getPath(), ZfechaFactura: new Date(), ZregeEstado: "SI", ZregeExento2: "NO EXENTO",Zmoneda:"EUR" }]);
			oView.setModel(this.jsonModelMonitor, "monitorCesvimap");
			var oTable = this.byId("tableMonitorF1");
			var ajustarCeros = this.ajustarCeros;
			oTable.attachBrowserEvent("paste", function (e) {
				e.stopPropagation();
				e.preventDefault();
				var data = e.originalEvent.clipboardData.getData('text/plain');
				if (data) {
					var rows = data.split("\r\n");
					var aPath = [];
					var index;
					for (var i in rows) {
						var row = rows[i];
						if (row) {
							if (i == 0) {
								var element = sap.ui.getCore().byId(e.target.parentElement.parentElement.id)
								if (!element) {
									return;
								}
								var tableRow = element.getParent();
								//Se obtiene la cella seleccionada
								if (!tableRow.getCells) {
									tableRow = tableRow.getParent();
								}
								var tableCells = tableRow.getCells();
								var indexCell;
								for (var c in tableCells) {
									if (tableCells[c].getId() === element.getId() || tableCells[c].getId() === element.getParent().getId()) {
										indexCell = parseInt(c);
										break;
									}
								}
								index = parseInt(tableRow.getBindingContext("monitorCesvimap").getPath().replace("/", ""));
								var contextObj = (new sap.ui.model.Context(tableRow.getBindingContext("monitorCesvimap").getModel(), "/" + index)).getObject();
								if (contextObj) {
									var cells = row.split("\t");
									for (var j in cells) {

										var path = tableCells[indexCell].getBindingPath("value") ? tableCells[indexCell].getBindingPath("value") : tableCells[indexCell].getBindingPath("selectedKey");
										if (path) {
											aPath.push({ id: path, editable: true });
											contextObj[path] = cells[j];
										} else {
											aPath.push({ id: path, editable: false });
										}
										indexCell = indexCell + 1;
									}

									contextObj.ZregeExento2 = contextObj.ZregeExento2.toUpperCase();
									contextObj.ZregeEstado = contextObj.ZregeEstado.toUpperCase();
									contextObj.ZfechaFactura = new Date(contextObj.ZfechaFactura);
									//contextObj.ZregeTextadic = contextObj.ZregeTextadic.substr(0,60);
									this.getModel().setProperty(contextObj._pathSmarfield + "/zsoc_receptora_fCesvimad", ajustarCeros(contextObj.zsoc_receptora_fCesvimad, 4))
									contextObj.ZsocReceptora = ajustarCeros(contextObj.zsoc_receptora_fCesvimad, 4);
									this.getModel().setProperty(contextObj._pathSmarfield + "/matnr", contextObj.matnr)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zcecoemisor", contextObj.Zcecoemisor)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zlnemisor", contextObj.Zlnemisor)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zcanalemisor", contextObj.Zcanalemisor)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zcecoreceptor", contextObj.Zcecoreceptor)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zlnreceptor", contextObj.Zlnreceptor)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zcanalreceptor", contextObj.Zcanalreceptor)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zcodsreceptor", contextObj.Zcodsreceptor)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zcuentareceptor", contextObj.Zcuentareceptor)

								}
							} else {
								index = index + 1;
								var contextObj = (new sap.ui.model.Context(this.getModel("monitorCesvimap"), "/" + index)).getObject();
								var cells = row.split("\t");
								if (contextObj) {
									for (var j in cells) {
										if (aPath[j].editable) {
											contextObj[aPath[j].id] = cells[j];
										}
									}
									contextObj.ZregeExento2 = contextObj.ZregeExento2.toUpperCase();
									contextObj.ZregeEstado = contextObj.ZregeEstado.toUpperCase();
									contextObj.ZfechaFactura = new Date(contextObj.ZfechaFactura);
									//contextObj.ZregeTextadic = contextObj.ZregeTextadic.substr(0,60);
									this.getModel().setProperty(contextObj._pathSmarfield + "/zsoc_receptora_fCesvimad", ajustarCeros(contextObj.zsoc_receptora_fCesvimad, 4))
									contextObj.ZsocReceptora = ajustarCeros(contextObj.zsoc_receptora_fCesvimad, 4);
									this.getModel().setProperty(contextObj._pathSmarfield + "/matnr", contextObj.matnr)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zcecoemisor", contextObj.Zcecoemisor)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zlnemisor", contextObj.Zlnemisor)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zcanalemisor", contextObj.Zcanalemisor)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zcecoreceptor", contextObj.Zcecoreceptor)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zlnreceptor", contextObj.Zlnreceptor)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zcanalreceptor", contextObj.Zcanalreceptor)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zcodsreceptor", contextObj.Zcodsreceptor)
									this.getModel().setProperty(contextObj._pathSmarfield + "/Zcuentareceptor", contextObj.Zcuentareceptor)

								} else {
									var item = {};
									for (var j in cells) {
										if (aPath[j].editable) {
											item[aPath[j].id] = cells[j];
										}
									}
									item.ZregeExento2 = item.ZregeExento2.toUpperCase();
									item.ZregeEstado = item.ZregeEstado.toUpperCase();
									//item.ZregeTextadic = item.ZregeTextadic.substr(0,60);
									item.ZfechaFactura = new Date(item.ZfechaFactura);
									item.ZsocEmisora = "0073";
									var oContextCreateBI = this.getModel().createEntry("/ZCMSD_REGE_MONF", {
										properties: {
											ZsocEmisora: item.ZsocEmisora,
											zsoc_receptora_fCesvimad: ajustarCeros(item.zsoc_receptora_fCesvimad, 4),
											matnr: item.matnr,
											Zcecoemisor: item.Zcecoemisor,
											Zlnemisor: item.Zlnemisor,
											Zcanalemisor: item.Zcanalemisor,
											Zcecoreceptor: item.Zcecoreceptor,
											Zlnreceptor: item.Zlnreceptor,
											Zcanalreceptor: item.Zcanalreceptor,
											Zcodsreceptor: item.Zcodsreceptor,
											Zcuentareceptor: item.Zcuentareceptor
										}
									})
									item.ZsocReceptora = ajustarCeros(item.zsoc_receptora_fCesvimad, 4);
									item._pathSmarfield = oContextCreateBI.getPath();
									this.getModel("monitorCesvimap").getData().push(item);
								}

							}
						}
					}
					this.getModel("monitorCesvimap").refresh();
				}

			});
		},
		ajustarCeros: function (field, length) {
			if (field && field.toString().length < length) {
				var ceros = length - field.toString().length;
				for (var i = 0; i < ceros; i++) {
					field = "0" + field;
				}
			}
			return field;
		},
		addMonitor: function () {
			var item = this.addLine.bind(this)();
			item.ZregeExento2 = "NO EXENTO"
			this.jsonModelMonitor.getData().push(item);
			this.getView().getModel("monitorCesvimap").refresh();
		},
		addLine: function () {
			var oContextCreateBI = this.getView().getModel().createEntry("/ZCMSD_REGE_MONF", {
				properties: {
					ZsocEmisora: "0073"
				}
			})
			return { ZsocEmisora: "0073", _pathSmarfield: oContextCreateBI.getPath(), ZfechaFactura: new Date(), ZregeEstado: "SI", ZregeExento2: "NO EXENTO" ,Zmoneda:"EUR"}

		},
		downloadTable: function () {
			if (!this._oTable) {
				this._oTable = this.byId("tableMonitorF1");
			}

			const oTable = this._oTable;
			const oRowBinding = oTable.getBinding("rows");
			const aCols = this.createColumnConfig(oTable.getColumns());
			const oSettings = {
				workbook: {
					columns: aCols,
					hierarchyLevel: "Level"
				},
				dataSource: oRowBinding,
				fileName: this.oResourceBundle.getText("ficheroXlSCesvimad") + ".xlsx",
				worker: false // We need to disable worker because we are using a MockServer as OData Service
			};

			const oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function () {
				oSheet.destroy();
			});
		},
		createColumnConfig: function (columns) {
			const aCols = [];
			for (var i in columns) {
				if (columns[i].getTemplate().getBindingInfo("value") && columns[i].getTemplate().getBindingInfo("value").parts[0].path === "ZfechaFactura") {
					aCols.push({
						label: columns[i].getLabel().getText(),
						property: "ZfechaFactura",
						type: EdmType.Date
					});
				} else {
					aCols.push({
						label: columns[i].getLabel().getText(),
						property: columns[i].getTemplate().getBindingInfo("value") ? columns[i].getTemplate().getBindingInfo("value").parts[0].path : columns[i].getTemplate().getBindingInfo("text") ? columns[i].getTemplate().getBindingInfo("text").parts[0].path : columns[i].getTemplate().getBindingInfo("selectedKey") ? columns[i].getTemplate().getBindingInfo("selectedKey").parts[0].path : "",
						type: EdmType.String
					});
				}
			}
			return aCols;
		},
		duplicateMonitor: function () {
			var tableMonitorF1 = this.getView().byId("tableMonitorF1");
			var aSelected = tableMonitorF1.getSelectedIndices();
			var oData = this.getView().getModel("monitorCesvimap").getData();
			for (var i in aSelected) {
				var item = jQuery.extend({}, oData[i]);
				var oContextCreateBI = this.getView().getModel().createEntry("/ZCMSD_REGE_MONF", {
					properties: {
						zsoc_receptora_fCesvimad: this.ajustarCeros(item.zsoc_receptora_fCesvimad, 4),
						matnr: item.matnr,
						Zcecoemisor: item.Zcecoemisor,
						Zlnemisor: item.Zlnemisor,
						Zcanalemisor: item.Zcanalemisor,
						Zcecoreceptor: item.Zcecoreceptor,
						Zlnreceptor: item.Zlnreceptor,
						Zcanalreceptor: item.Zcanalreceptor,
						Zcuentareceptor: item.Zcuentareceptor,
						Zcodsreceptor: item.Zcodsreceptor
					}
				})
				item._pathSmarfield = oContextCreateBI.getPath();
				oData.push(item);
			}
			this.getView().getModel("monitorCesvimap").refresh();
			jQuery.sap.delayedCall(100, this, function () {
				var oTable = this.byId("tableMonitorF1");
				var fieldGroup = oTable.getControlsByFieldGroupId("fg1");
				for (var i in fieldGroup) {
					if (fieldGroup[i].checkValuesValidity) {
						if (!fieldGroup[i].getValue()) {
							fieldGroup[i].setValueState("Error");
						} else {
							fieldGroup[i].checkValuesValidity()
						}
					}
				}
			})

		},
		onDeleteMonitor: function (oEvent) {
			var tableMonitorF1 = this.getView().byId("tableMonitorF1");
			var aIndex = tableMonitorF1.getSelectedIndices();
			var objectMonitorCesvimap = this.getView().getModel("monitorCesvimap").getData();
			var aMonitor = [];
			for (var i in objectMonitorCesvimap) {
				if (aIndex.filter((index) => index == i).length == 0) {
					aMonitor.push(objectMonitorCesvimap[i]);
				};
			}
			this.getView().getModel("monitorCesvimap").setData(aMonitor);
			debugger

		},
		onChangeFechaFactura: function (oEvent) {
			if (oEvent.getSource().getDateValue() < new Date() && oEvent.getSource().getDateValue().toLocaleDateString() != new Date().toLocaleDateString()) {
				var oItemMonitor = oEvent.getSource().getBindingContext("monitorCesvimap").getObject();
				oItemMonitor._statusFechaFactura = "Error";
				oItemMonitor._messageErrorFechaFactura = this.oResourceBundle.getText("fechaNoPuedeSerInferior")
			} else {
				var oItemMonitor = oEvent.getSource().getBindingContext("monitorCesvimap").getObject();
				oItemMonitor._statusFechaFactura = "None";
				oItemMonitor._messageErrorFechaFactura = this.oResourceBundle.getText("fechaNoPuedeSerInferior")
			}
		},
		onChangeSocRecep: function (oEvent) {
			var objectContext = oEvent.getSource().getBindingContext("monitorCesvimap").getObject();
			objectContext.ZsocReceptora = arguments[0].getParameter("value");
		},
		onChangeMaterial: function (oEvent) {
			var objectContext = oEvent.getSource().getBindingContext("monitorCesvimap").getObject();
			objectContext.matnr = arguments[0].getParameter("value");
		},
		onChangeCecoEmisor: function (oEvent) {
			var objectContext = oEvent.getSource().getBindingContext("monitorCesvimap").getObject();
			objectContext.Zcecoemisor = arguments[0].getParameter("value");
		},
		onChangeLNEmisor: function (oEvent) {
			var objectContext = oEvent.getSource().getBindingContext("monitorCesvimap").getObject();
			objectContext.Zlnemisor = arguments[0].getParameter("value");
		},
		onChangeCanalEmisor: function (oEvent) {
			var objectContext = oEvent.getSource().getBindingContext("monitorCesvimap").getObject();
			objectContext.Zcanalemisor = arguments[0].getParameter("value");
		},
		onChangeCecoReceptor: function (oEvent) {
			var objectContext = oEvent.getSource().getBindingContext("monitorCesvimap").getObject();
			objectContext.Zcecoreceptor = arguments[0].getParameter("value");
		},
		onChangeLNReceptor: function (oEvent) {
			var objectContext = oEvent.getSource().getBindingContext("monitorCesvimap").getObject();
			objectContext.Zlnreceptor = arguments[0].getParameter("value");
		},
		onChangeCanalReceptor: function (oEvent) {
			var objectContext = oEvent.getSource().getBindingContext("monitorCesvimap").getObject();
			objectContext.Zcanalreceptor = arguments[0].getParameter("value");
		},
		onChangeCuentaReceptor: function (oEvent) {
			var objectContext = oEvent.getSource().getBindingContext("monitorCesvimap").getObject();
			objectContext.Zcuentareceptor = arguments[0].getParameter("value");
		},
		onChangeCodServicioRec: function (oEvent) {
			var objectContext = oEvent.getSource().getBindingContext("monitorCesvimap").getObject();
			objectContext.Zcodsreceptor = arguments[0].getParameter("value");
		},
		rowsUpdated: function (oEvent) {
			var rows = oEvent.getSource().getRows();
			for (var i in rows) {
				//Por cada fila debes settear el binding que se haya creado un binding para el smartfield
				if (rows[i].getBindingContext("monitorCesvimap")) {
					var objectContext = rows[i].getBindingContext("monitorCesvimap").getObject()
					rows[i].bindElement(objectContext._pathSmarfield);
				}
			}
		},
		onRecuperarBIREGE: function (oEvent, forceWarning,_aMessagesNoExento) {


			sap.ui.core.BusyIndicator.show();
			var monitorCData = this.getView().getModel("monitorCesvimap").getData();
			//Validar campos obligatorios
			var hasError = false;
			var hasWarning = false;
			var aMessages = [];
			if(_aMessagesNoExento){
				aMessages = _aMessagesNoExento;
				hasWarning = true;
			}
			var _Zsocemisora = "",
				_Zsocreceptora = "",
				_Matnr = "",
				_Zcecoemisor = "",
				_Zlnemisor = "",
				_Zcanalemisor = "",
				_Zcecoreceptor = "",
				_Zlnreceptor = "",
				_Zcanalreceptor = "",
				_Zcuentareceptor = "",
				_Zcodsreceptor = "";

			for (var i in monitorCData) {
				var oItem = monitorCData[i];
				//Id facturacion
				if (!oItem.ZregeIdfact) {
					oItem._ZregeIdfactStatus = "Error";
					var message = {};
					message.group = this.oResourceBundle.getText("fila") + ' ' + (parseInt(i) + 1);
					message.message = this.oResourceBundle.getText("idFacturacionVacia");
					aMessages.push(message);
					hasError = true;
				}

				//Servicio
				if (!oItem.ZregeServicio) {
					oItem._ZregeServicioStatus = "Error";
					var message = {};
					message.group = this.oResourceBundle.getText("fila") + ' ' + (parseInt(i) + 1);
					message.message = this.oResourceBundle.getText("servicioVacia");
					aMessages.push(message);
					hasError = true;
				}

				//Importe
				if (!oItem.ZregeImporte) {
					oItem._ZregeImporteStatus = "Error";
					var message = {};
					message.group = this.oResourceBundle.getText("fila") + ' ' + (parseInt(i) + 1);
					message.message = this.oResourceBundle.getText("importeVacia");
					aMessages.push(message);
					hasError = true;
				}

				//Fecha fact
				if (!oItem.ZfechaFactura || (oItem.ZfechaFactura < new Date() && oItem.ZfechaFactura.toLocaleDateString() != new Date().toLocaleDateString())) {
					oItem._statusFechaFactura = "Error";
					var message = {};
					message.group = this.oResourceBundle.getText("fila") + ' ' + (parseInt(i) + 1);
					if (!oItem.ZfechaFactura) {
						message.message = this.oResourceBundle.getText("fechaFactVacia");
					} else {
						message.message = this.oResourceBundle.getText("fechaNoPuedeSerInferior");
					}
					aMessages.push(message);
					hasError = true;
				}

				//Se concatenan los valores para vlaidarlo con el function import
				_Zsocreceptora = _Zsocreceptora + oItem.ZsocReceptora + ";"
				_Matnr = _Matnr + oItem.matnr + ";"
				_Zcecoemisor = _Zcecoemisor + oItem.Zcecoemisor + ";"
				_Zlnemisor = _Zlnemisor + oItem.Zlnemisor + ";"
				_Zcanalemisor = _Zcanalemisor + (oItem.Zcanalemisor || "") + ";"
				_Zcecoreceptor = _Zcecoreceptor + (oItem.Zcecoreceptor || "") + ";"
				_Zlnreceptor = _Zlnreceptor + (oItem.Zlnreceptor || "") + ";"
				_Zcanalreceptor = _Zcanalreceptor + (oItem.Zcanalreceptor || "") + ";"
				_Zcuentareceptor = _Zcuentareceptor + (oItem.Zcuentareceptor || "") + ";"
				_Zcodsreceptor = _Zcodsreceptor + (oItem.Zcodsreceptor || "") + ";"
			}


			if (!forceWarning) {
				var duplicados = this.encontrarDuplicados.bind(this)(monitorCData, [
					'ZsocReceptora',
					'matnr',
					'Zcecoemisor',
					'Zlnemisor',
					'Zcanalemisor',
					'Zcecoreceptor',
					'Zlnreceptor',
					'Zcanalreceptor',
					'Zcuentareceptor',
					'Zcodsreceptor',
					'ZregeServicio',
					'ZregeTextadic',
					'Zsocemisora'
				]);


				if (duplicados.length > 0) {
					hasWarning = true;
					duplicados.forEach(element => {
						var indices = [];
						element.indices.forEach(item => {
							indices.push(item.index);
						})
						var message = {};
						message.severity = 'W';
						message.message = this.oResourceBundle.getText("duplicadoLinea", [indices.toString()]);
						message.group = ""
						aMessages.push(message);

					});

				}
			}

			var oTable = this.byId("tableMonitorF1");
			var fieldGroup = oTable.getControlsByFieldGroupId("fg1");
			var aPromise = []
			for (var i in fieldGroup) {
				if (fieldGroup[i].checkValuesValidity) {
					if (!fieldGroup[i].getValue()) {
						fieldGroup[i].setValueState("Error");
					} else {
						aPromise.push(fieldGroup[i].checkValuesValidity())
					}
				}
			}

			this.getView().getModel("monitorCesvimap").refresh();

			Promise.all(aPromise).then(function () {

				this.getView().getModel().callFunction(
					"/CheckValues", {
					method: "POST",
					urlParameters: {
						Zsocemisora: '0073',
						Zsocreceptora: _Zsocreceptora,
						Matnr: _Matnr,
						Zcecoemisor: _Zcecoemisor,
						Zlnemisor: _Zlnemisor,
						Zcanalemisor: _Zcanalemisor,
						Zcecoreceptor: _Zcecoreceptor,
						Zlnreceptor: _Zlnreceptor,
						Zcanalreceptor: _Zcanalreceptor,
						Zcuentareceptor: _Zcuentareceptor,
						Zcodsreceptor: _Zcodsreceptor
					},
					success: function (oData, response) {
						sap.ui.core.BusyIndicator.hide();
						if (hasError && aMessages.length>0) {
							aMessages = this.armarMensajFront(aMessages);
							this.mostrarMensajes(aMessages, this);
							return;
						}

						if (hasWarning  && aMessages.length>0) {
							for(var i in aMessages){
								aMessages[i].message = aMessages[i].message + this.oResourceBundle.getText("duplicadoLineaContinuar");
							}
							aMessages = this.armarMensajFront(aMessages);
							this.mostrarMensajes(aMessages, this, function () {
								this.onRecuperarBIREGE({}, true)
							}.bind(this));
							return;
						}

						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("monitorFact");
						var auxData = this.getView().getModel("aux").getData();
						var aFilterSocRec = [];
						for (var i in monitorCData) {
							aFilterSocRec.push(new sap.ui.model.Filter("zsoc_receptora", "EQ", monitorCData[i].ZsocReceptora));
						}
						var aFilters = [
							new sap.ui.model.Filter("zsoc_emisora", "EQ", "0073"),
							new sap.ui.model.Filter({ filters: aFilterSocRec, and: false }),
							new sap.ui.model.Filter("zrege_mes", "EQ", auxData._mes),
							new sap.ui.model.Filter("zrege_year", "EQ", auxData._anio)
						]
						this.getView().getModel("bipbi").read("/ZCMSD_REGE_BIPBI", {
							filters: aFilters,
							success: function (oData) {
								for (var i in monitorCData) {
									for (var j in oData.results) {
										if (monitorCData[i].ZsocReceptora === oData.results[j].zsoc_receptora) {
											monitorCData[i].ZregeBiapli = oData.results[j].zrege_bi;
											monitorCData[i].Emisor = oData.results[j].Emisor;
											monitorCData[i].Receptor = oData.results[j].Receptor;
											break;
										}
									}

								}
								//Recalcular IVA y mas campos
								var index = null;
								for (var i in monitorCData) {
									if (index !== monitorCData[i].ZsocReceptora) {
										index = monitorCData[i].ZsocReceptora;
										Utils._recalcularItem(monitorCData[i], monitorCData, parseInt(i), 0)
									}

								}
								var tableMonitor = monitorCData;
								//Agregamos la logica del pintado de lineas separatorias
								if (tableMonitor.length > 1) {
									var biIguales = 1;
									for (var i = 1; i < tableMonitor.length; i++) {
										if (tableMonitor[i].ZsocReceptora !== tableMonitor[i - 1].ZsocReceptora ||
											tableMonitor[i].ZsocEmisora !== tableMonitor[i - 1].ZsocEmisora) {
											tableMonitor[i - 1]._ultimoReg = true;
											tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
											biIguales = 1
											//Ultimo registro
											if (i == (tableMonitor.length - 1)) {
												tableMonitor[i]._ultimoReg = true;
												tableMonitor[i]._visibleBI = true;
											}
										} else {
											biIguales = biIguales + 1;
										}
									}
									if (biIguales > 1) {
										tableMonitor[i - 1]._ultimoReg = true;
										tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
										biIguales = 1
									}
								} else if (tableMonitor.length === 1) {
									tableMonitor[0]._ultimoReg = true;
									tableMonitor[0]._visibleBI = true;
								}

								this.getView().getModel("monitor").setData(tableMonitor);
							}.bind(this),
							error: function () {
								debugger
							}

						})
					}.bind(this),
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide();
						var mensajes = JSON.parse(oError.responseText).error.innererror.errordetails;

						if (mensajes.length > 0) {
							mensajes.pop();

							if (mensajes.length > 0) {

								mensajes.forEach(mensaje => {
									mensaje.group = this.oResourceBundle.getText("fila") + ' ' + parseInt(mensaje.message.slice(6, 10));
									mensaje.message = mensaje.message.slice(20);

								});

								if (hasError || hasWarning) {
									for (var i in aMessages) {
										mensajes.push(aMessages[i]);
									}
								}

								mensajes = this.armarMensajFront(mensajes);
								this.mostrarMensajes(mensajes, this);
							}
						} else {
							sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
						}
					}.bind(this)
				}
				);


			}.bind(this)).catch(function () {
				// the value is invalid
				hasError = true;
			});
		},
		onCancelar: function () {
			Utils.cancelar.bind(this)();
		},
		validateFG: function (oEvent) {
			debugger
		},
		onChangeIdFact: function (oEvent) {
			if (oEvent.getSource().getValue()) {
				oEvent.getSource().setValueState("None")
			}
		},
		onChangeServicio: function (oEvent) {
			if (oEvent.getSource().getValue()) {
				oEvent.getSource().setValueState("None")
			}
		},
		onChangeImporte: function (oEvent) {
			if (oEvent.getSource().getValue()) {
				oEvent.getSource().setValueState("None")
			}
		},
		armarMensajFront: function (mensaje) {
			var mensajes = [];

			if (mensaje.length) {
				for (var i = 0; i < mensaje.length; i++) {
					mensajes.push({
						"Type": mensaje[i].severity,
						"Message": mensaje[i].message,
						"Group": mensaje[i].group
					});
				}
			}
			return mensajes;
		},
		mostrarMensajes: function (mensajes, thes, callback) {


			/*var mensajes = [{
				"Type": "E",
				"Message": "Mensaje de prueba"
			}];*/

			for (var i = 0; i < mensajes.length; i++) {
				switch (mensajes[i].Type) {
					case "E":
						mensajes[i].Type = "Error";
						break;
					case "S":
						mensajes[i].Type = "Success";
						break;
					case "W":
						mensajes[i].Type = "Warning";
						break;
					case "I":
						mensajes[i].Type = "Information";
						break;
					case "error":
						mensajes[i].Type = "Error";
						break;
					case "success":
						mensajes[i].Type = "Success";
						break;
					case "warning":
						mensajes[i].Type = "Warning";
						break;
					case "info":
						mensajes[i].Type = "Information";
						break;
				}
			}

			var oMessageTemplate = new sap.m.MessageItem({
				type: '{Type}',
				title: '{Message}',
				groupName: '{Group}'
			});

			var oModel = new sap.ui.model.json.JSONModel(mensajes);

			var oBackButton = new sap.m.Button({
				icon: sap.ui.core.IconPool.getIconURI("nav-back"),
				visible: false,
				press: function () {
					thes.oMessageView.navigateBack();
					this.setVisible(false);
				}
			});

			this.oMessageView = new sap.m.MessageView({
				showDetailsPageHeader: false,
				itemSelect: function () {
					oBackButton.setVisible(true);
				},
				items: {
					path: "/",
					template: oMessageTemplate
				},
				groupItems: true
			});

			this.oMessageView.setModel(oModel);

			this.oDialog = new sap.m.Dialog({
				resizable: true,
				content: this.oMessageView,
				beginButton: new sap.m.Button({
					press: function (oEvent) {
						sap.ui.getCore().byId(oEvent.getSource().getParent().getId()).close();
					},
					text: "Close"
				}),
				customHeader: new sap.m.Bar({
					contentMiddle: [
						new sap.m.Text({
							text: "Mensajes"
						})
					],
					contentLeft: [oBackButton]
				}),
				contentHeight: "50%",
				contentWidth: "50%",
				verticalScrolling: false
			});
			if (callback) {
				this.oDialog.setBeginButton(new sap.m.Button({
					text: this.oResourceBundle.getText("continuar"),
					press: callback.bind(this)
				}))
			}

			this.oMessageView.navigateBack();
			this.oDialog.open();



		},
		formatMounth: function (mounth) {
			return Utils.formatMounth.bind(this)(mounth);
		},
		onFileChange: function (oEvent) {
			var oFile = oEvent.getParameter("files")[0];

			var reader = new FileReader();

			reader.onload = function (e) {
				var oNewService = [];

				sap.ui.core.BusyIndicator.show();

				var data = e.target.result;
				var workbook = XLSX.read(data, {
					type: 'binary',
					cellDates: true
				});
				console.log(workbook)

				var oMessages = [];

				workbook.SheetNames.forEach(function (sheetName) {

					var XL_row_object =
						XLSX.utils.sheet_to_row_object_array(
							workbook.Sheets[sheetName]);
					if (XL_row_object.length !== 0) {

						var table = this.byId("tableMonitorF1");
						var columns = table.getColumns();
						var index = 0
						XL_row_object.forEach(XL_row => {
							let newService = this.addLine.bind(this)();
							index = index + 1;
							const filaExcel = this.oResourceBundle.getText("fila") + " " + index;
							for (var i in columns) {
								var path = columns[i].getTemplate().getBindingInfo("value") ? columns[i].getTemplate().getBindingInfo("value").parts[0].path : columns[i].getTemplate().getBindingInfo("text") ? columns[i].getTemplate().getBindingInfo("text").parts[0].path : columns[i].getTemplate().getBindingInfo("selectedKey") ? columns[i].getTemplate().getBindingInfo("selectedKey").parts[0].path : ""
								newService[path] = XL_row[columns[i].getLabel().getText()]?.toString() ?? "";
							}

							if (XL_row["F. facturación*"]) {
								XL_row["F. facturación*"] = XL_row["F. facturación*"].replaceAll ? this.parseFecha(XL_row["F. facturación*"]) :XL_row["F. facturación*"]; 
								var fechaFact = new Date(XL_row["F. facturación*"]);
								fechaFact = new Date(fechaFact.getTime() - (fechaFact.getTimezoneOffset() * 60 * 1000));
								newService.ZfechaFactura = fechaFact;
							} else {
								newService.ZfechaFactura = null;
							}
							
							newService.ZregeExento2 = newService.ZregeExento2.toUpperCase();
							//No exento
							if (newService.ZregeExento2 !== "NO EXENTO" && newService.ZregeExento2 !== "EXENTO") {
								newService.ZregeExento2 = "NO EXENTO";
								var message = {};
								message.severity = 'W';
								message.group = filaExcel;
								message.message = this.oResourceBundle.getText("errorIVA");
								oMessages.push(message);
							}
							newService.ZregeEstado = newService.ZregeEstado.toUpperCase();
							//newService.ZregeTextadic = newService.ZregeTextadic.substr(0,60);
							newService.ZsocEmisora = "0073";
							newService.zsoc_receptora_fCesvimad = this.ajustarCeros(newService.zsoc_receptora_fCesvimad, 4)
							newService.ZsocReceptora = this.ajustarCeros(newService.zsoc_receptora_fCesvimad, 4);


							this.getView().getModel().setProperty(newService._pathSmarfield + "/matnr", newService.matnr)
							this.getView().getModel().setProperty(newService._pathSmarfield + "/Zcecoemisor", newService.Zcecoemisor)
							this.getView().getModel().setProperty(newService._pathSmarfield + "/Zlnemisor", newService.Zlnemisor)
							this.getView().getModel().setProperty(newService._pathSmarfield + "/Zcecoreceptor", newService.Zcecoreceptor)
							this.getView().getModel().setProperty(newService._pathSmarfield + "/zsoc_receptora_fCesvimad", newService.zsoc_receptora_fCesvimad)
							this.getView().getModel().setProperty(newService._pathSmarfield + "/Zcanalemisor", newService.Zcanalemisor)
							this.getView().getModel().setProperty(newService._pathSmarfield + "/Zlnreceptor", newService.Zlnreceptor)
							this.getView().getModel().setProperty(newService._pathSmarfield + "/Zcanalreceptor", newService.Zcanalreceptor)
							this.getView().getModel().setProperty(newService._pathSmarfield + "/Zcuentareceptor", newService.Zcuentareceptor)
							this.getView().getModel().setProperty(newService._pathSmarfield + "/Zcodsreceptor", newService.Zcodsreceptor)
							oNewService.push(newService);

						});

					}

				}.bind(this))

				this.getView().getModel("monitorCesvimap").setData(oNewService);

				//if (oMessages.length === 0) {
					jQuery.sap.delayedCall(100, this, function () {
						this.onRecuperarBIREGE({},false,oMessages);
					}.bind(this))
				/*} else {
					oMessages = this.armarMensajFront(oMessages);
					this.mostrarMensajes(oMessages, this);
					sap.ui.core.BusyIndicator.hide();
				}*/


			}.bind(this);

			reader.onerror = function (ex) {
				console.log(ex);
			};

			reader.readAsBinaryString(oFile);

		},
		parseFecha: function(fechaStr) {
			// Primero validamos el formato yyyy.mm.dd
			let match = fechaStr.match(/^(\d{4})\.(\d{2})\.(\d{2})$/);
			if (match) {
				const [_, year, month, day] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}

			// Validamos el formato yyyy/mm/dd
			match = fechaStr.match(/^(\d{4})\/(\d{2})\/(\d{2})$/);
			if (match) {
				const [_, year, month, day] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}
		
			// Luego validamos el formato dd.mm.yyyy
			match = fechaStr.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
			if (match) {
				const [_, day, month, year] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}

			// Luego validamos el formato dd-mm-yyyy
			match = fechaStr.match(/^(\d{2})\-(\d{2})\-(\d{4})$/);
			if (match) {
				const [_, day, month, year] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}

			// Luego validamos el formato yyyy-mm-dd
			match = fechaStr.match(/^(\d{4})\-(\d{2})\-(\d{2})$/);
			if (match) {
				const [_, year, month, day] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}
		
			return null; // No coincide con ninguno
		},
		eliminaDuplicados: function (arr) {

			const unicos = [];
			const claves = [];

			for (var i = 0; i < arr.length; i++) {

				const clave = arr[i].clave;
				const element = arr[i];

				if (!claves.includes(arr[i].clave)) {
					claves.push(clave);
					unicos.push(element);
				}
			}

			return unicos;
		},


		encontrarDuplicados: function (arr, campos) {

			const mapa = new Map();
			const duplicados = [];

			arr.forEach((obj, indice) => {

				const clave = campos.map(campo => obj[campo]).join('|');

				if (mapa.get(clave)) {
					//Se comprueba que el rango de fechas no coinciden
					var aMapeo = mapa.get(clave);
					aMapeo.push({ index: indice + 1, obj: obj });
				} else {
					mapa.set(clave, [{ index: indice + 1, obj: obj }]);
				}

				mapa.forEach((indices, clave) => {
					if (indices.length > 1) {
						duplicados.push({ clave, indices });
					}
				});

			});

			return this.eliminaDuplicados(duplicados);
		}
	});
}); 