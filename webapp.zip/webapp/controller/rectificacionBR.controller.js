sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"mapfre/net/zsdmonitorfact/utils/Utils",
	"mapfre/net/zsdmonitorfact/lib/xlsx.full.min",
	"sap/ui/export/Spreadsheet",
	"sap/ui/export/library",
], (Controller, Utils, xlsxLib, Spreadsheet, exportLibrary) => {
	"use strict";

	return Controller.extend("mapfre.net.zsdmonitorfact.controller.rectificacionBR", {
		onAfterRendering: function () {
			this.proceso = null;
			this.mes = null;
			this.anio = null;
			this.oResourceBundle = this.getView().getModel("i18n").getResourceBundle();


		},
		formatMounth: function (mounth) {
			return Utils.formatMounth.bind(this)(mounth);
		},
		rowsUpdated: function () {
			this.pintarLineaImporte();
		},
		pintarLineaImporte: function () {
			var oTable = this.getView().byId("tableMonitorRecBR");
			var aRows = oTable.getRows();
			if (aRows && aRows.length > 0) {
				//Filas que se deben borrar
				for (var iR in aRows) {
					//Agregamos el copiado en la columna de importe y texto adicional
					aRows[iR].getCells()[6].attachBrowserEvent("paste", function (e) {
						e.stopPropagation();

						e.preventDefault();
						var data = e.originalEvent.clipboardData.getData('text/plain');
						if (data) {
							var rows = data.split("\r\n");
							for (var i in rows) {
								var index = parseInt(this.getBindingContext("monitor").getPath().replace("/", "")) + parseInt(i)
								var contextObj = (new sap.ui.model.Context(this.getBindingContext("monitor").getModel(), "/" + index)).getObject();
								if (contextObj) {
									contextObj.ZregeTextadic = rows[i].split("\t")[0];

									if (rows[i].split("\t")[1]) {
										contextObj.ZregeImporte = parseFloat(rows[i].split("\t")[1].replace(",", "."));
									}
								} else {
									break;
								}
							}
							var oItemMonitor = this.getBindingContext("monitor").getObject();
							var aMonitor = this.getBindingContext("monitor").getModel().getData();
							Utils._recalcularItem(oItemMonitor, aMonitor, 0, 0);
							this.getBindingContext("monitor").getModel().refresh();
						}

					});
					aRows[iR].getCells()[7].attachBrowserEvent("paste", function (e) {
						e.stopPropagation();

						e.preventDefault();
						var data = e.originalEvent.clipboardData.getData('text/plain');
						if (data) {
							var rows = data.split("\r\n");
							for (var i in rows) {
								var index = parseInt(this.getBindingContext("monitor").getPath().replace("/", "")) + parseInt(i)
								var contextObj = (new sap.ui.model.Context(this.getBindingContext("monitor").getModel(), "/" + index)).getObject();
								if (contextObj) {
									contextObj.ZregeImporte = parseFloat(rows[i].split("\t")[0].replace(",", "."));
								} else {
									break;
								}
							}
							var oItemMonitor = this.getBindingContext("monitor").getObject();
							var aMonitor = this.getBindingContext("monitor").getModel().getData();
							Utils._recalcularItem(oItemMonitor, aMonitor, 0, 0);
							this.getBindingContext("monitor").getModel().refresh();
						}

					});
				}
				aRows.map((aRow, i) => {
					if (aRow.getBindingContext("monitor")) {
						if (aRow.getBindingContext("monitor").getObject()._ultimoReg) {
							for (var c in aRow.getCells()) {
								$("#" + aRow.getCells()[c].getId()).parent().parent().css("border-bottom", "2px black solid");
							}
						} else {
							for (var c in aRow.getCells()) {
								if (c != 4) {
									$("#" + aRow.getCells()[c].getId()).parent().parent().css("border-bottom", ".0625rem solid #e5e5e5");
								} else {
									$("#" + aRow.getCells()[4].getId()).parent().parent().css("border-bottom-style", "hidden");
								}
							}
						}
						if (!aRow.getBindingContext("monitor").getObject()._visibleBI) {
							$("#" + aRow.getCells()[4].getId()).css("display", "none");
						} else {
							$("#" + aRow.getCells()[4].getId()).css("display", "block");
							$("#" + aRow.getCells()[4].getId()).css("text-align", "right");
						}
					}
				})
			}
		},
		onChangeImporte: function (oEvent) {
			var oItemMonitor = oEvent.getSource().getBindingContext("monitor").getObject();
			var aMonitor = this.getView().getModel("monitor").getData();
			//Obtener el sumatorio de los importes de su grupo
			//Se obtiene todos los importes de las posiciones que tengan igual emisor y receptor
			/*for(var i in aMonitor){
				var oItem = aMonitor[i];
				if(oItem.ZsocEmisora == oItemMonitor.ZsocEmisora && oItem.ZsocReceptora== oItemMonitor.ZsocReceptora){
					sumImporte = sumImporte + parseFloat(oItem.ZregeImporte);
				} 
			}
			
			oItemMonitor.ZregeHistBiapli = (ZregeBiapli/sumImporte) * oItemMonitor.ZregeImporte;*/
			Utils._recalcularItem(oItemMonitor, aMonitor, 0, 0);
			oEvent.getSource().getBindingContext("monitor").getModel().refresh();

		},
		onChangeFechaFactura: function (oEvent) {
			if (oEvent.getSource().getDateValue() < new Date() && oEvent.getSource().getDateValue().toLocaleDateString() != new Date().toLocaleDateString()) {
				var oItemMonitor = oEvent.getSource().getBindingContext("monitor").getObject();
				oItemMonitor._statusFechaFactura = "Error";
				oItemMonitor._messageErrorFechaFactura = this.oResourceBundle.getText("fechaNoPuedeSerInferior")
			} else {
				var oItemMonitor = oEvent.getSource().getBindingContext("monitor").getObject();
				oItemMonitor._statusFechaFactura = "None";
				oItemMonitor._messageErrorFechaFactura = this.oResourceBundle.getText("fechaNoPuedeSerInferior")
			}
		},
		onSelectFacturar: function (oEvent) {
			var oItemMonitor = oEvent.getSource().getBindingContext("monitor").getObject();
			var aMonitor = this.getView().getModel("monitor").getData();
			for (var i in aMonitor) {
				if (aMonitor[i].ZregeProc == 'NO' && aMonitor[i].ZsocEmisora == oItemMonitor.ZsocEmisora && aMonitor[i].ZsocReceptora == oItemMonitor.ZsocReceptora && aMonitor[i].ZregeIdfact == oItemMonitor.ZregeIdfact) {
					aMonitor[i].ZregeEstado = oItemMonitor.ZregeEstado;
				}
			}
			oEvent.getSource().getBindingContext("monitor").getModel()
		},
		onGenerarPedido: function () {
			var auxData = this.getView().getModel("aux").getData();
			var mes = auxData._mes;
			var anio = auxData._anio;
			var zsocemisora = "";
			var odata = jQuery.extend(true, [], this.getView().getModel("monitor").getData());
			var Array = []
			for (var i in odata) {
				if (odata[i].ZregeProc == 'SI') {
					if (odata[i].ZregeEstado == 'SI') {
						odata[i].ZregeImporte = odata[i].ZregeImporte + "";
						odata[i].Zinverso = "X";
						switch (odata[i].ZsocEmisora) {
							case '0002':
								odata[i].ZregeTipo = 'ZREC'
								break;
							case '0003':
								odata[i].ZregeTipo = 'ZREC'
								break;
							case 'Y051':
								odata[i].ZregeTipo = 'ZPFC'
								break;
							case '0073':
								odata[i].ZregeTipo = 'ZPFC'
								break;
						}
						Array.push(odata[i]);
					} else {
						for (var h in odata) {
							if (odata[h].ZregeProc == 'NO' && odata[i].ZsocEmisora == odata[h].ZsocEmisora &&
								odata[i].ZsocReceptora == odata[h].ZsocReceptora &&
								odata[i].ZregeServicio == odata[h].ZregeServicio &&
								odata[i].Matnr == odata[h].Matnr &&
								odata[i].Zcecoemisor == odata[h].Zcecoemisor &&
								odata[i].Zlnemisor == odata[h].Zlnemisor &&
								odata[i].Zcanalemisor == odata[h].Zcanalemisor &&
								odata[i].Zcecoreceptor == odata[h].Zcecoreceptor &&
								odata[i].Zlnreceptor == odata[h].Zlnreceptor &&
								odata[i].Zcanalreceptor == odata[h].Zcanalreceptor &&
								odata[i].Zcuentareceptor == odata[h].Zcuentareceptor
							) {
								if (!odata[h]._cargado) {
									odata[h]._cargado = true;
									odata[h].Zrectificacion = "X";
									Array.push(odata[h])
									break;
								}
							}
						}
					}
				} else {
					if (!odata[i]._cargado) {
						odata[i]._cargado = true;
						odata[i].ZregeImporte = odata[i].ZregeImporte + "";
						odata[i].Zrectificacion = "NEW";
						odata[i].ZregeTipo = 'ZAFC'
						Array.push(odata[i]);
					}
				}
				
				odata[i].ZregeBinr = parseFloat(odata[i].ZregeBinr).toFixed(2)
				odata[i].ZregeHistBiapli = parseFloat(odata[i].ZregeHistBiapli).toFixed(2)
				odata[i].ZregeIva = parseFloat(odata[i].ZregeIva).toFixed(2);
				odata[i].ZregeImporte = parseFloat(odata[i].ZregeImporte).toFixed(2)
				zsocemisora = odata[i].ZsocEmisora;
			}
			for (var i in odata) {
				for (var j in odata[i]) {
					if (j.indexOf("_") === 0) {
						odata[i][j] = undefined;
					}
				}
			}
			this.dialogWaitPedido = new sap.m.Dialog(
				{
					showHeader: false,
					content: [
						new sap.m.HBox({ justifyContent: "Center", alignItems: "Center", items: [new sap.m.BusyIndicator({ text: "{i18n>procesandoPedido}" })] })
					]
				}
			)
			this.getView().addDependent(this.dialogWaitPedido);
			this.dialogWaitPedido.open();
			var item = {
				matnr: "",
				Zcanalemisor: "",
				Zcanalreceptor: "",
				Zcecoemisor: "",
				Zcecoreceptor: "",
				Zcodsreceptor: "",
				Zcuentareceptor: "",
				Zlnemisor: "",
				Zlnreceptor: "",
				ZregeExento: "",
				ZregeIdfact: "",
				ZregeRenuncia: "",
				ZregeServicio: "",
				ZsocEmisora: "",
				ZsocReceptora: "",
				Zmonitor: "RECBI",
				Zcsv: "",
				HeaderToItem: odata
			};
			var _filtroReceptores = auxData._filtroReceptores;
			this.getView().getModel().create("/Header_monfSet", item, {
				success: function (oResult, oResponse) {
					var csvString = oResult.Zcsv;
					/*if (csvString) {
						var arrayOfArrayCsv = csvString.split("\n").map(row => {
							return row.split(";")
						});
						var wb = XLSX.utils.book_new();
						var newWs = XLSX.utils.aoa_to_sheet(arrayOfArrayCsv);
						XLSX.utils.book_append_sheet(wb, newWs);
						var rawExcel = XLSX.write(wb, { type: 'base64' })
						this.getView().getModel().create("/xlsxSet", { string: rawExcel }, {
							success: function () {
								this.dialogWaitPedido.close();
							}.bind(this),
							error: function () {*/
								this.dialogWaitPedido.close();
								var aFilters = [];
								aFilters.push(new sap.ui.model.Filter("ZsocEmisora", "EQ", zsocemisora));
								//aFilters.push(new sap.ui.model.Filter("ZregeHistMes", "EQ", mes));
								aFilters.push(new sap.ui.model.Filter("ZregeMes", "EQ", mes));
								aFilters.push(new sap.ui.model.Filter("ZregeYear", "EQ", anio));
								aFilters.push(_filtroReceptores)
								this.getView().getModel().read("/ZCMSD_REGE_HIST2", {
									filters: aFilters,
									success: function (oData) {
										this.showLog = true;
										auxData.showLog = true;
										this.getView().getModel("aux").refresh();
										var tableMonitor = oData.results;
										tableMonitor.sort((a, b) => {
											var nameA = a.ZsocEmisora + "|" + a.ZsocReceptora + "|" + a.ZregeBiapli;
											var nameB = b.ZsocEmisora + "|" + b.ZsocReceptora + "|" + b.ZregeBiapli;
											if (nameA < nameB) {
												return -1;
											}
											if (nameA > nameB) {
												return 1;
											}
											return 0;
										});

										if (tableMonitor.length > 1) {
											var biIguales = 1;
											for (var i = 1; i < tableMonitor.length; i++) {
												if (tableMonitor[i].ZsocReceptora !== tableMonitor[i - 1].ZsocReceptora ||
													tableMonitor[i].ZsocEmisora !== tableMonitor[i - 1].ZsocEmisora ||
													tableMonitor[i].ZregeBiapli !== tableMonitor[i - 1].ZregeBiapli) {
													tableMonitor[i - 1]._ultimoReg = true;
													tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
													biIguales = 1
													//Ultimo registro
													if (i == (tableMonitor.length - 1)) {
														tableMonitor[i]._ultimoReg = true;
														tableMonitor[i]._visibleBI = true;
													}
												} else {
													biIguales = biIguales + 1;
												}
											}
											if (biIguales > 1) {
												tableMonitor[i - 1]._ultimoReg = true;
												tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
												biIguales = 1
											}
										} else if (tableMonitor.length === 1) {
											tableMonitor[0]._ultimoReg = true;
											tableMonitor[0]._visibleBI = true;
										}
										this.getView().getModel("monitor").setData(tableMonitor);
									}.bind(this)
								});

							/*}.bind(this)
						})
					} else {
						this.dialogWaitPedido.close();
					}*/
				}.bind(this),
				error: function (oError) {
					var mensajes = JSON.parse(oError.responseText).error.innererror.errordetails;
					mensajes = this.armarMensajFront(mensajes);
					this.mostrarMensajes(mensajes, this);
					this.dialogWaitPedido.close();
				}.bind(this)
			});
		},
		onCancelar: function () {
			Utils.cancelar.bind(this)();;
		},
	});
});