sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"mapfre/net/zsdmonitorfact/utils/Utils",
	"mapfre/net/zsdmonitorfact/lib/xlsx.full.min",
	"sap/ui/export/Spreadsheet",
	"sap/ui/export/library",
], (Controller, Utils, xlsxLib, Spreadsheet, exportLibrary) => {
	"use strict";

	const EdmType = exportLibrary.EdmType;

	return Controller.extend("mapfre.net.zsdmonitorfact.controller.View1", {
		onAfterRendering: function () {
			this.cesvimap = false;
			this.proceso = null;
			this.mes = null;
			this.anio = null;
			this.oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			this.showLog = false;
			var oTable = this.byId("tableMonitor");
			this.oTable = oTable;
			oTable.onAfterRendering = function () {
				sap.ui.table.Table.prototype.onAfterRendering.apply(this, arguments);

			};

		},

		pintarLineaImporte: function () {
			var oTable = this.oTable;
			var aRows = oTable.getRows();
			if (aRows && aRows.length > 0) {
				//Filas que se deben borrar
				for (var iR in aRows) {
					//Agregamos el copiado en la columna de importe y texto adicional
					aRows[iR].getCells()[7].attachBrowserEvent("paste", function (e) {
						e.stopPropagation();

						e.preventDefault();
						var data = e.originalEvent.clipboardData.getData('text/plain');
						if (data) {
							var rows = data.split("\r\n");
							for (var i in rows) {
								if(rows[i] !== "" || i != (rows.length- 1)){
								var index = parseInt(this.getBindingContext("monitor").getPath().replace("/", "")) + parseInt(i)
								var contextObj = (new sap.ui.model.Context(this.getBindingContext("monitor").getModel(), "/" + index)).getObject();
								if (contextObj) {
									contextObj.ZregeTextadic = rows[i].split("\t")[0];

									if (rows[i].split("\t")[1]) {
										contextObj.ZregeImporte = parseFloat(rows[i].split("\t")[1].replaceAll(".","").replace(",", "."))
										contextObj.ZregeImporte = parseFloat(contextObj.ZregeImporte).toFixed(2);
									}
								} else {
									break;
								}
							}
							}
							var oItemMonitor = this.getBindingContext("monitor").getObject();
							var aMonitor = this.getBindingContext("monitor").getModel().getData();
							Utils._recalcularItemFacturacion(oItemMonitor, aMonitor, 0, 0, 0);
							this.getBindingContext("monitor").getModel().refresh();
						}

					});
					aRows[iR].getCells()[8].attachBrowserEvent("paste", function (e) {
						e.stopPropagation();

						e.preventDefault();
						var data = e.originalEvent.clipboardData.getData('text/plain');
						if (data) {
							var rows = data.split("\r\n");
							for (var i in rows) {
								if(rows[i] !== "" || i != (rows.length- 1)){
									var index = parseInt(this.getBindingContext("monitor").getPath().replace("/", "")) + parseInt(i)
									var contextObj = (new sap.ui.model.Context(this.getBindingContext("monitor").getModel(), "/" + index)).getObject();
									if (contextObj) {
										contextObj.ZregeImporte = parseFloat(rows[i].split("\t")[0].replaceAll(".","").replace(",", "."))
										contextObj.ZregeImporte = parseFloat(contextObj.ZregeImporte).toFixed(2);;
									} else {
										break;
									}
								}
							}
							var oItemMonitor = this.getBindingContext("monitor").getObject();
							var aMonitor = this.getBindingContext("monitor").getModel().getData();
							Utils._recalcularItemFacturacion(oItemMonitor, aMonitor, 0, 0, 0);
							this.getBindingContext("monitor").getModel().refresh();
						}

					});
				}
				aRows.map((aRow, i) => {
					if (aRow.getBindingContext("monitor")) {
						if (aRow.getBindingContext("monitor").getObject()._ultimoReg) {
							for (var c in aRow.getCells()) {
								$("#" + aRow.getCells()[c].getId()).parent().parent().css("border-bottom", "2px black solid");
							}
						} else {
							for (var c in aRow.getCells()) {
								if (c != 5) {
									$("#" + aRow.getCells()[c].getId()).parent().parent().css("border-bottom", ".0625rem solid #e5e5e5");
								} else {
									$("#" + aRow.getCells()[5].getId()).parent().parent().css("border-bottom-style", "hidden");
								}
							}
						}
						if (!aRow.getBindingContext("monitor").getObject()._visibleBI) {
							$("#" + aRow.getCells()[5].getId()).css("display", "none");
						} else {
							$("#" + aRow.getCells()[5].getId()).css("display", "block");
							$("#" + aRow.getCells()[5].getId()).css("text-align", "right");
						}
					}
					//}
					//pRow = aRow;

				});
				//oTable.rerender()
			}
		},

		updateFinished: function () {
			this.oTable.rerender()
		},

		rowsUpdated: function () {
			this.pintarLineaImporte();
		},

		onChangeImporte: function (oEvent) {
			var oItemMonitor = oEvent.getSource().getBindingContext("monitor").getObject();
			var aMonitor = this.getView().getModel("monitor").getData();

			Utils._recalcularItemFacturacion(oItemMonitor, aMonitor, 0, 0, 0);
			oEvent.getSource().getBindingContext("monitor").getModel().refresh();

		},
		onChangeFechaFactura: function (oEvent) {
			if (oEvent.getSource().getDateValue() < new Date() && oEvent.getSource().getDateValue().toLocaleDateString() != new Date().toLocaleDateString()) {
				var oItemMonitor = oEvent.getSource().getBindingContext("monitor").getObject();
				oItemMonitor._statusFechaFactura = "Error";
				oItemMonitor._messageErrorFechaFactura = this.oResourceBundle.getText("fechaNoPuedeSerInferior")
			} else {
				var oItemMonitor = oEvent.getSource().getBindingContext("monitor").getObject();
				oItemMonitor._statusFechaFactura = "None";
				oItemMonitor._messageErrorFechaFactura = this.oResourceBundle.getText("fechaNoPuedeSerInferior")
			}
		},
		onSelectFacturar: function (oEvent) {
			var oItemMonitor = oEvent.getSource().getBindingContext("monitor").getObject();
			var aMonitor = this.getView().getModel("monitor").getData();
			for (var i in aMonitor) {
				if (aMonitor[i].ZsocEmisora == oItemMonitor.ZsocEmisora && aMonitor[i].ZsocReceptora == oItemMonitor.ZsocReceptora && aMonitor[i].ZregeIdfact == oItemMonitor.ZregeIdfact) {
					aMonitor[i].ZregeEstado = oItemMonitor.ZregeEstado;
				}
			}
			Utils._recalcularItemFacturacion(oItemMonitor, aMonitor, 0, 0, 0);
			oEvent.getSource().getBindingContext("monitor").getModel().refresh();
		},
		onCancelar: function () {
			Utils.cancelar.bind(this)();
		},
		onGenerarPedido: function () {

			var auxData = this.getView().getModel("aux").getData();
			var mes = auxData._mes;
			var anio = auxData._anio;
			var zsocemisora = "";

			var odata = jQuery.extend(true, [], this.getView().getModel("monitor").getData());
			for (var i in odata) {
				for (var j in odata[i]) {
					if (j.indexOf("_") === 0) {
						odata[i][j] = undefined;
					}
				}
				odata[i].ZregeImporte = odata[i].ZregeImporte + ""
				if (!auxData.reprocesable) {
					odata[i].Zindex = undefined;
				}
				odata[i].ZidLog = undefined;
				//odata[i].indice = odata[i].Zindex;
				//odata[i].Zindex = undefined;
				/*if(odata[i].ZsocEmisora == '0073'){
					odata[i].ZregeServicio = odata[i].ZregeServicio + "("+odata[i].ZregeIdfact+")";
				}*/
				odata[i].ZregeMes = auxData._mes;
				odata[i].ZregeYear = auxData._anio;
				odata[i].ZregeBinr = parseFloat(odata[i].ZregeBinr).toFixed(2)
				odata[i].ZregeHistBiapli = parseFloat(odata[i].ZregeHistBiapli).toFixed(2)
				odata[i].ZregeIva = parseFloat(odata[i].ZregeIva).toFixed(2);
				odata[i].ZregeImporte = parseFloat(odata[i].ZregeImporte).toFixed(2)
				zsocemisora = odata[i].ZsocEmisora;
				if (odata[i].ZregeEstado === 'SI') {
					odata[i].ZregeTipo = 'ZPFC'
				}
				odata[i].Zmoneda = 'EUR';
				if (odata[i].ZsocEmisora == '0073') {
					odata[i].ZregeExento = odata[i].ZregeExento2;
				}

				odata[i].ZfechaFactura = new Date(odata[i].ZfechaFactura.getTime() - (odata[i].ZfechaFactura.getTimezoneOffset() * 60 * 1000))
				odata[i].Zregeiddocumento = undefined;

			}
			this.dialogWaitPedido = new sap.m.Dialog(
				{
					showHeader: false,
					content: [
						new sap.m.HBox({ justifyContent: "Center", alignItems: "Center", items: [new sap.m.BusyIndicator({ text: "{i18n>procesandoPedido}" })] })
					]
				}
			)
			this.getView().addDependent(this.dialogWaitPedido);
			this.dialogWaitPedido.open();
			var item = {
				matnr: "",
				Zcanalemisor: "",
				Zcanalreceptor: "",
				Zcecoemisor: "",
				Zcecoreceptor: "",
				Zcodsreceptor: "",
				Zcuentareceptor: "",
				Zlnemisor: "",
				Zlnreceptor: "",
				ZregeExento: "",
				ZregeIdfact: "",
				ZregeRenuncia: "",
				ZregeServicio: "",
				ZsocEmisora: "",
				ZsocReceptora: "",
				Zmonitor: "FACT",
				Zcsv: "",
				HeaderToItem: odata
			};
			var _filtroReceptores = auxData._filtroReceptores;
			this.getView().getModel().create("/Header_monfSet", item, {
				success: function (oResult, oResponse) {
					var csvString = oResult.Zcsv;
					if (csvString) {
						var arrayOfArrayCsv = csvString.split("\n").map(row => {
							return row.split(";")
						});
						var wb = XLSX.utils.book_new();
						var newWs = XLSX.utils.aoa_to_sheet(arrayOfArrayCsv);
						XLSX.utils.book_append_sheet(wb, newWs);
						var rawExcel = XLSX.write(wb, { type: 'base64' })
						var ids = "";
						for (var i in oResult.HeaderToItem.results) {
							ids = ids + "" + oResult.HeaderToItem.results[i].Zindex + ";";
						}
						this.getView().getModel().create("/xlsxSet", { string: rawExcel, ids: ids }, {
							success: function () {
								this.dialogWaitPedido.close();
							}.bind(this),
							error: function (error) {
								this.dialogWaitPedido.close();
								this.errorDetail = JSON.parse(error.responseText).error.innererror.errordetails;
								var aFilters = [];
								aFilters.push(new sap.ui.model.Filter("ZsocEmisora", "EQ", zsocemisora));
								aFilters.push(new sap.ui.model.Filter("ZregeMes", "EQ", mes));
								aFilters.push(new sap.ui.model.Filter("ZregeYear", "EQ", anio));
								aFilters.push(_filtroReceptores)
								this.getView().getModel().read("/ZCMSD_REGE_HIST2", {
									filters: aFilters,
									success: function (oData) {
										var tableMonitor = oData.results;
										tableMonitor.sort((a, b) => {
											var nameA = a.ZsocEmisora + "|" + a.ZsocReceptora + "|" + a.ZregeBiapli;
											var nameB = b.ZsocEmisora + "|" + b.ZsocReceptora + "|" + b.ZregeBiapli;
											if (nameA < nameB) {
												return -1;
											}
											if (nameA > nameB) {
												return 1;
											}
											return 0;
										});

										if (tableMonitor.length > 1) {
											var biIguales = 1;
											for (var i = 1; i < tableMonitor.length; i++) {
												if (tableMonitor[i].ZsocReceptora !== tableMonitor[i - 1].ZsocReceptora ||
													tableMonitor[i].ZsocEmisora !== tableMonitor[i - 1].ZsocEmisora ||
													tableMonitor[i].ZregeBiapli !== tableMonitor[i - 1].ZregeBiapli) {
													tableMonitor[i - 1]._ultimoReg = true;
													tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
													biIguales = 1
													//Ultimo registro
													if (i == (tableMonitor.length - 1)) {
														tableMonitor[i]._ultimoReg = true;
														tableMonitor[i]._visibleBI = true;
													}
												} else {
													biIguales = biIguales + 1;
												}
											}
											if (biIguales > 1) {
												tableMonitor[i - 1]._ultimoReg = true;
												tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
												biIguales = 1
											}
										} else if (tableMonitor.length === 1) {
											tableMonitor[0]._ultimoReg = true;
											tableMonitor[0]._visibleBI = true;
										}
										this.getView().getModel("aux").setProperty("/showLog", true);
										this.showLog = true;
										//Se comprueba is hay alguna posicioon que sea facturado en true y que haya fallado la creacion del pedido
										//Tambien en el caso de que sea facturado en no.
										for (var i in tableMonitor) {
											if (tableMonitor[i].ZregeEstado === 'SI' && tableMonitor[i].VbelnVa === '') {
												this.getView().getModel("aux").setProperty("/reprocesable", true);
											}else if (tableMonitor[i].ZregeEstado === 'NO'){
												this.getView().getModel("aux").setProperty("/reprocesable", true);
												tableMonitor[i]._refacturable = true;
											}
										}
										this.getView().getModel("monitor").setData(tableMonitor);

									}.bind(this)
								})
								/*if(zsocemisora == '0073'){
									this.getView().getModel().read("/ZCMSD_REGE_MONR", {
										filters: aFilters,
										success: function (oData) {
											this.showLog = true;
											auxData.showLog = true;
											this.getView().getModel("aux").refresh();
											this.getView().getModel("monitor").setData(oData.results);
										}.bind(this)
									});
								}else{
									aFilters.push(new sap.ui.model.Filter("ZregeHistMes", "EQ", mes));
									this.getView().getModel().read("/ZCMSD_REGE_MONF", {
										filters: aFilters,
										success: function (oData) {
											this.showLog = true;
											auxData.showLog = true;
											this.getView().getModel("aux").refresh();
											this.getView().getModel("monitor").setData(oData.results);
										}.bind(this)
									});
								}*/

							}.bind(this)
						})
					} else {
						this.dialogWaitPedido.close();
						var aFilters = [];
						aFilters.push(new sap.ui.model.Filter("ZsocEmisora", "EQ", zsocemisora));
						aFilters.push(new sap.ui.model.Filter("ZregeMes", "EQ", mes));
						aFilters.push(new sap.ui.model.Filter("ZregeYear", "EQ", anio));
						aFilters.push(_filtroReceptores)
						this.getView().getModel().read("/ZCMSD_REGE_HIST2", {
							filters: aFilters,
							success: function (oData) {
								var tableMonitor = oData.results;
								tableMonitor.sort((a, b) => {
									var nameA = a.ZsocEmisora + "|" + a.ZsocReceptora + "|" + a.ZregeBiapli;
									var nameB = b.ZsocEmisora + "|" + b.ZsocReceptora + "|" + b.ZregeBiapli;
									if (nameA < nameB) {
										return -1;
									}
									if (nameA > nameB) {
										return 1;
									}
									return 0;
								});

								if (tableMonitor.length > 1) {
									var biIguales = 1;
									for (var i = 1; i < tableMonitor.length; i++) {
										if (tableMonitor[i].ZsocReceptora !== tableMonitor[i - 1].ZsocReceptora ||
											tableMonitor[i].ZsocEmisora !== tableMonitor[i - 1].ZsocEmisora ||
											tableMonitor[i].ZregeBiapli !== tableMonitor[i - 1].ZregeBiapli) {
											tableMonitor[i - 1]._ultimoReg = true;
											tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
											biIguales = 1
											//Ultimo registro
											if (i == (tableMonitor.length - 1)) {
												tableMonitor[i]._ultimoReg = true;
												tableMonitor[i]._visibleBI = true;
											}
										} else {
											biIguales = biIguales + 1;
										}
									}
									if (biIguales > 1) {
										tableMonitor[i - 1]._ultimoReg = true;
										tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
										biIguales = 1
									}
								} else if (tableMonitor.length === 1) {
									tableMonitor[0]._ultimoReg = true;
									tableMonitor[0]._visibleBI = true;
								}
								this.getView().getModel("aux").setProperty("/showLog", true);
								this.showLog = true;
								//Se comprueba is hay alguna posicioon que sea facturado en true y que haya fallado la creacion del pedido
								for (var i in tableMonitor) {
									if (tableMonitor[i].ZregeEstado === 'SI' && tableMonitor[i].VbelnVa === '') {
										this.getView().getModel("aux").setProperty("/reprocesable", true);
									}
								}
								this.getView().getModel("monitor").setData(tableMonitor);

							}.bind(this)
						})
					}
				}.bind(this),
				error: function (oError) {
					debugger
					this.dialogWaitPedido.close();
				}.bind(this)
			});

		},
		formatMounth: function (mounth) {
			return Utils.formatMounth.bind(this)(mounth);
		},
		downloadTable: function () {
			if (!this._oTable) {
				this._oTable = this.byId("tableMonitor");
			}

			const oTable = this._oTable;
			const oRowBinding = oTable.getBinding("rows");
			const aCols = this.createColumnConfig(oTable.getColumns());
			var socEmisora = "";
			if (this.getView().getModel("monitor").getData().length > 0) {
				socEmisora = this.getView().getModel("monitor").getData()[0].Emisor;
			}
			var auxData = this.getView().getModel("aux").getData();
			const oSettings = {
				workbook: {
					columns: aCols,
					hierarchyLevel: "Level"
				},
				dataSource: oRowBinding,
				fileName: this.oResourceBundle.getText("ficheroXlS") + ' ' + socEmisora + " " +this.formatMounth(auxData._mes)+" "+auxData._anio + ".xlsx",
				worker: false // We need to disable worker because we are using a MockServer as OData Service
			};

			const oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function () {
				oSheet.destroy();
			});
		},
		createColumnConfig: function (columns) {
			const aCols = [];
			for (var i in columns) {
				if (columns[i].getTemplate().getBindingInfo("value") && columns[i].getTemplate().getBindingInfo("value").parts[0].path === "ZfechaFactura") {
					aCols.push({
						label: columns[i].getLabel().getText(),
						property: "ZfechaFactura",
						type: EdmType.Date
					});

				}
				else if (columns[i].getTemplate().getBindingInfo("value") && columns[i].getTemplate().getBindingInfo("value").parts[0].path === "ZregeServicio") {
					aCols.push({
						label: columns[i].getLabel().getText(),
						property: ["ZregeServicio", "ZregeSegreparto"],
						type: EdmType.String,
						template: "{0} {1}"
					});
				}
				else if (columns[i].getTemplate().getBindingInfo("text") && columns[i].getTemplate().getBindingInfo("text").parts[0].path === "ZregeServicio") {
					aCols.push({
						label: columns[i].getLabel().getText(),
						property: ["ZregeServicio", "ZregeSegreparto"],
						type: EdmType.String,
						template: "{0} {1}"
					});
				} else {
					aCols.push({
						label: columns[i].getLabel().getText(),
						property: columns[i].getTemplate().getBindingInfo("value") ? columns[i].getTemplate().getBindingInfo("value").parts[0].path : columns[i].getTemplate().getBindingInfo("text") ? columns[i].getTemplate().getBindingInfo("text").parts[0].path : columns[i].getTemplate().getBindingInfo("selectedKey") ? columns[i].getTemplate().getBindingInfo("selectedKey").parts[0].path : "",
						type: EdmType.String
					});
				}
			}
			return aCols;
		},
		onFileChange: function (oEvent) {
			var oFile = oEvent.getParameter("files")[0];

			var reader = new FileReader();

			reader.onload = function (e) {

				sap.ui.core.BusyIndicator.show();

				var data = e.target.result;
				var workbook = XLSX.read(data, {
					type: 'binary',
					cellDates: true
				});
				console.log(workbook)

				var oMessages = [];

				workbook.SheetNames.forEach(function (sheetName) {

					var XL_row_object =
						XLSX.utils.sheet_to_row_object_array(
							workbook.Sheets[sheetName]);
					if (XL_row_object.length !== 0) {

						var table = this.byId("tableMonitor");
						var odata = this.getView().getModel("monitor").getData();
						var columns = table.getColumns();
						var index = 0
						XL_row_object.forEach(XL_row => {
							let service = {};
							var item = odata[index];
							index = index + 1;
							for (var i in columns) {
								var path = columns[i].getTemplate().getBindingInfo("value") ? columns[i].getTemplate().getBindingInfo("value").parts[0].path : columns[i].getTemplate().getBindingInfo("text") ? columns[i].getTemplate().getBindingInfo("text").parts[0].path : columns[i].getTemplate().getBindingInfo("selectedKey") ? columns[i].getTemplate().getBindingInfo("selectedKey").parts[0].path : ""
								service[path] = XL_row[columns[i].getLabel().getText()]?.toString() ?? "";
							}
							if (XL_row["F. facturación*"]) {
								XL_row["F. facturación*"] = XL_row["F. facturación*"].replaceAll ? this.parseFecha(XL_row["F. facturación*"]) :XL_row["F. facturación*"]; 
								var fechaFact = new Date(XL_row["F. facturación*"]);
								fechaFact = new Date(fechaFact.getTime() - (fechaFact.getTimezoneOffset() * 60 * 1000));
								service.ZfechaFactura = fechaFact;
							} else {
								service.ZfechaFactura = null;
							}
							item.ZregeTextadic = service.ZregeTextadic;
							item.ZregeImporte = service.ZregeImporte;
							item.ZregeEstado = service.ZregeEstado;
							item.ZfechaFactura = service.ZfechaFactura;

						});

					}

				}.bind(this))

				this.getView().getModel("monitor").refresh();

				if (oMessages.length === 0) {
					sap.ui.core.BusyIndicator.hide();
					jQuery.sap.delayedCall(100, this, function () {

					}.bind(this))
				} else {
					mensajes = this.armarMensajFront(mensajes);
					this.mostrarMensajes(mensajes, this);
					sap.ui.core.BusyIndicator.hide();
				}


			}.bind(this);

			reader.onerror = function (ex) {
				console.log(ex);
			};

			reader.readAsBinaryString(oFile);

		},
		parseFecha: function(fechaStr) {
			// Primero validamos el formato yyyy.mm.dd
			let match = fechaStr.match(/^(\d{4})\.(\d{2})\.(\d{2})$/);
			if (match) {
				const [_, year, month, day] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}

			// Validamos el formato yyyy/mm/dd
			match = fechaStr.match(/^(\d{4})\/(\d{2})\/(\d{2})$/);
			if (match) {
				const [_, year, month, day] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}
		
			// Luego validamos el formato dd.mm.yyyy
			match = fechaStr.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
			if (match) {
				const [_, day, month, year] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}

			// Luego validamos el formato dd-mm-yyyy
			match = fechaStr.match(/^(\d{2})\-(\d{2})\-(\d{4})$/);
			if (match) {
				const [_, day, month, year] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}

			// Luego validamos el formato yyyy-mm-dd
			match = fechaStr.match(/^(\d{4})\-(\d{2})\-(\d{2})$/);
			if (match) {
				const [_, year, month, day] = match;
				const date = new Date(`${year}-${month}-${day}`);
				return date;
			}
		
			return null; // No coincide con ninguno
		},
		armarMensajFront: function (mensaje) {
			var mensajes = [];

			if (mensaje.length) {
				for (var i = 0; i < mensaje.length; i++) {
					mensajes.push({
						"Type": mensaje[i].severity,
						"Message": mensaje[i].message,
						"Group": mensaje[i].group
					});
				}
			}
			return mensajes;
		},
		mostrarMensajes: function (mensajes, thes, callback) {


			/*var mensajes = [{
				"Type": "E",
				"Message": "Mensaje de prueba"
			}];*/

			for (var i = 0; i < mensajes.length; i++) {
				switch (mensajes[i].Type) {
					case "E":
						mensajes[i].Type = "Error";
						break;
					case "S":
						mensajes[i].Type = "Success";
						break;
					case "W":
						mensajes[i].Type = "Warning";
						break;
					case "I":
						mensajes[i].Type = "Information";
						break;
					case "error":
						mensajes[i].Type = "Error";
						break;
					case "success":
						mensajes[i].Type = "Success";
						break;
					case "warning":
						mensajes[i].Type = "Warning";
						break;
					case "info":
						mensajes[i].Type = "Information";
						break;
				}
			}

			var oMessageTemplate = new sap.m.MessageItem({
				type: '{Type}',
				title: '{Message}',
				groupName: '{Group}'
			});

			var oModel = new sap.ui.model.json.JSONModel(mensajes);

			var oBackButton = new sap.m.Button({
				icon: sap.ui.core.IconPool.getIconURI("nav-back"),
				visible: false,
				press: function () {
					thes.oMessageView.navigateBack();
					this.setVisible(false);
				}
			});

			this.oMessageView = new sap.m.MessageView({
				showDetailsPageHeader: false,
				itemSelect: function () {
					oBackButton.setVisible(true);
				},
				items: {
					path: "/",
					template: oMessageTemplate
				},
				groupItems: true
			});

			this.oMessageView.setModel(oModel);

			this.oDialog = new sap.m.Dialog({
				resizable: true,
				content: this.oMessageView,
				beginButton: new sap.m.Button({
					press: function (oEvent) {
						sap.ui.getCore().byId(oEvent.getSource().getParent().getId()).close();
					},
					text: "Close"
				}),
				customHeader: new sap.m.Bar({
					contentMiddle: [
						new sap.m.Text({
							text: "Mensajes"
						})
					],
					contentLeft: [oBackButton]
				}),
				contentHeight: "50%",
				contentWidth: "50%",
				verticalScrolling: false
			});
			if (callback) {
				this.oDialog.setBeginButton(new sap.m.Button({
					text: this.oResourceBundle.getText("continuar"),
					press: callback.bind(this)
				}))
			}

			this.oMessageView.navigateBack();
			this.oDialog.open();



		},
		infoError: function (oEvent) {
			var contextObj = oEvent.getSource().getBindingContext("monitor").getObject();
			var mensajes = [];
			if (this.errorDetail) {
				for (var i in this.errorDetail) {
					if (this.errorDetail[i].message.substr(0, 5) === contextObj.Zregeiddocumento) {
						var message = {};
						message.severity = contextObj.VbelnVa ? 'S' :  'W';
						message.message = this.errorDetail[i].message;
						message.group = this.errorDetail[i].message.substr(0, 5)
						if(this.errorDetail[i].message.substr(5,this.errorDetail[i].message.length) != ""){
							mensajes.push(message);
						}
					}
				}
				mensajes = this.armarMensajFront(mensajes);
				this.mostrarMensajes(mensajes, this);
			} else {
				var aFilters = [
					new sap.ui.model.Filter("Zindex", "EQ", contextObj.ZidLog),
					new sap.ui.model.Filter("ZregeIddocumento", "EQ", contextObj.Zregeiddocumento),
				]
				this.getView().getModel().read("/ZCMSD_REGE_LOG", {
					filters: aFilters,
					success: function (oData) {
						for (var i in oData.results) {
							var message = {};
							message.severity = oData.results[i].VbelnVa ? 'S' :  'W';
							message.message = oData.results[i].Zmensaje;
							message.group = contextObj.Zregeiddocumento;
							
						if(this.errorDetail[i].message.substr(5,this.errorDetail[i].message.length) != ""){
							mensajes.push(message);
						}
						}

						mensajes = this.armarMensajFront(mensajes);
						this.mostrarMensajes(mensajes, this);
					}.bind(this)
				});
			}

		}
	});
});