sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "mapfre/net/zsdmonitorfact/utils/Utils"
], (BaseController, Utils) => {
  "use strict";

  return BaseController.extend("mapfre.net.zsdmonitorfact.controller.App", {
    onInit: function () {
      var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
      if (oRouter.getHashChanger().hash) {
        if (window.location.href.indexOf("&/" + oRouter.getHashChanger().hash) > -1) {
          window.location.href = window.location.href.replace("&/" + oRouter.getHashChanger().hash, "");
        } else {
          window.location.href = window.location.href.replace("/" + oRouter.getHashChanger().hash, "");
        }
        window.location.reload();
      }
    },
    onAfterRendering: function () {
      this.oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
      this.jsonModelMonitor = new sap.ui.model.json.JSONModel([]);
      var oView = this.getView();
      oView.setModel(this.jsonModelMonitor, "monitor")
      oView.setModel(new sap.ui.model.json.JSONModel({}), "aux")
      if (!this._oDialogSeleccion) {
        this._oDialogSeleccion = sap.ui.xmlfragment("createBI", "mapfre.net.zsdmonitorfact.fragments.Seleccion", this);
        oView.addDependent(this._oDialogSeleccion);
      }

      jQuery.sap.delayedCall(1000, this, function () {

        var oContextCreateBI = this.getView().getModel().createEntry("/ZCMSD_REGE_MONF", {
          properties: {
            ZregeReej: 'NO'
          }
        })
        this._oDialogSeleccion.getContent()[0].bindElement(oContextCreateBI.getPath());
      }.bind(this))
      this._oDialogSeleccion.open();
    },
    onChangeProceso: function (oEvent) {
      var path = this._oDialogSeleccion.getContent()[0].getBindingContext().getPath();
      if (oEvent.getSource().getSelectedKey() == 2) {
        this.getView().getModel().setProperty(path + "/ZregeEstado", "SI");
      } else {
        this.getView().getModel().setProperty(path + "/ZregeEstado", undefined);
      }
      if (oEvent.getSource().getSelectedKey() == 1) {
        this.getView().getModel().setProperty(path + "/ZregeReej", "SI");
      } else {
        this.getView().getModel().setProperty(path + "/ZregeReej", "NO");
      }
    },
    onChangeMes: function (oEvent) {
      var path = this._oDialogSeleccion.getContent()[0].getBindingContext().getPath();
      this.getView().getModel().setProperty(path + "/ZregeHistMes", oEvent.getSource().getValue())
    },
    onChangeYear: function (oEvent) {
      var path = this._oDialogSeleccion.getContent()[0].getBindingContext().getPath();
      this.getView().getModel().setProperty(path + "/ZregeHistYear", oEvent.getSource().getValue())
    },
    onContinuarDetalle: function () {
      //Se comprueba que todos los campos esten rellenos
      var socEmisora = sap.ui.core.Fragment.byId("createBI", "socEmisora")
      var socReceptora = sap.ui.core.Fragment.byId("createBI", "socReceptora")
      var socReceptoraCesvimad = sap.ui.core.Fragment.byId("createBI", "socReceptoraCesvimad")
      var socReceptoraHist = sap.ui.core.Fragment.byId("createBI", "socReceptoraHist")
      var periodo = sap.ui.core.Fragment.byId("createBI", "periodo")
      var anio = sap.ui.core.Fragment.byId("createBI", "anio")
      var proceso = sap.ui.core.Fragment.byId("createBI", "proceso")

      if (!socEmisora.getValue()) {
        var message = this.oResourceBundle.getText("debRellenarSocEmi")
        sap.m.MessageToast.show(message);
        return;
      } else {
        if (socEmisora.getValue() === '0073') {
          socReceptora = socReceptoraCesvimad;
        }
      }
      if (proceso.getSelectedKey() == 1 || proceso.getSelectedKey() == 2 || proceso.getSelectedKey() == 3) {
        socReceptora = socReceptoraHist;
      }
      if (socReceptora.getTokens().length === 0) {
        var message = this.oResourceBundle.getText("debRellenarSocRec")
        sap.m.MessageToast.show(message);
        return;
      }
      if (!periodo.getValue()) {
        var message = this.oResourceBundle.getText("debRellenarPeriodo")
        sap.m.MessageToast.show(message);
        return;
      }
      if (!anio.getValue()) {
        var message = this.oResourceBundle.getText("debRellenarAnio")
        sap.m.MessageToast.show(message);
        return;
      }
      var socEmisora = socEmisora.getValue();
      var mes = this.ajustarCeros(periodo.getValue(), 2);
      var anio = anio.getValue()

      //Comprobar si el mes y año no es igual o superior
      var date = new Date();
      if (anio > date.getFullYear() || (anio == date.getFullYear() && parseInt(mes) >= parseInt((date.getMonth() + 1)))) {
        var message = this.oResourceBundle.getText("AnioPeriodoFuturo")
        sap.m.MessageToast.show(message);
        return;
      }

      var aFilters = [
        new sap.ui.model.Filter("ZsocEmisora", "EQ", socEmisora),

        new sap.ui.model.Filter("ZregeYear", "EQ", anio)
      ]
      var aFilterSocRec = []
      this.socReceptoras = [];
      for (var i in socReceptora.getTokens()) {
        aFilterSocRec.push(new sap.ui.model.Filter("ZsocReceptora", "EQ", socReceptora.getTokens()[i].getKey()))
        this.socReceptoras.push(socReceptora.getTokens()[i].getKey());
      }
      aFilters.push(new sap.ui.model.Filter({ filters: aFilterSocRec, and: false }))
      this.cesvimap = socEmisora == "0073";
      this.mes = mes;
      this.anio = anio;
      var auxData = this.getView().getModel("aux").getData();
      auxData._mes = this.mes;
      auxData._anio = this.anio;
      auxData._filtroReceptores = new sap.ui.model.Filter({ filters: aFilterSocRec, and: false });
      this.getView().getModel("aux").refresh();
      //this.proceso = proceso.getSelectedKey();
      var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

      if (proceso.getSelectedKey() == 1 || proceso.getSelectedKey() == 2) {
        if (proceso.getSelectedKey() == 2) {
          oRouter.navTo("rectificacionImp");
          aFilters.push(new sap.ui.model.Filter("ZregeMes", "EQ", mes));
            aFilters.push(new sap.ui.model.Filter("ZregeEstado", "EQ", "SI"));
          if (this.cesvimap) {
            this.readDataRectificacion.bind(this)(aFilters, "/ZCMSD_REGE_HIST2");
          } else {
            aFilters.push(new sap.ui.model.Filter("ZregeHistMes", "EQ", this.mes))
            aFilters.push(new sap.ui.model.Filter("ZregeHistYear", "EQ", this.anio));
            this.readDataRectificacion.bind(this)(aFilters, "/ZCMSD_REGE_MONF");            
          }

        } else {
          oRouter.navTo("rectificacionBR");
          aFilters.push(new sap.ui.model.Filter("ZregeMes", "EQ", mes));
          if (this.cesvimap) {
            this.readDataRectificacionBR.bind(this)(aFilters, "/ZCMSD_REGE_HIST_BI");
          } else {
            aFilters.push(new sap.ui.model.Filter("ZregeHistMes", "EQ", this.mes))
            aFilters.push(new sap.ui.model.Filter("ZregeHistYear", "EQ", this.anio));
            this.readDataRectificacionBR.bind(this)(aFilters, "/ZCMSD_REGE_MONF");
          }
          
          
          
        }

        this._oDialogSeleccion.close();
      }
      else if (proceso.getSelectedKey() == 3) {
        oRouter.navTo("regularizacion");
        aFilters.push(new sap.ui.model.Filter("ZregeMes", "LE", mes));
        aFilters.push(new sap.ui.model.Filter("ZregeProc", "EQ", "SI"));
        this.getView().getModel().read("/ZCMSD_REGE_MONR", {
          filters: aFilters,
          success: function (oData) {
            var tableMonitor = oData.results;
            //Obtenemos el aculado por socReceptora
            var groupJson = this.groupByWithoutBI(tableMonitor);
            var tableMonitor = [];
            for (var i in groupJson) {
              var item = jQuery.extend(true, {}, groupJson[i][0]);
              var _factAcumulada = 0;
              var _BASEREGEAplicada = 0;
              for (var j in groupJson[i]) {
                _factAcumulada = _factAcumulada + parseFloat(groupJson[i][j].ZregeImporte);
                _BASEREGEAplicada = _BASEREGEAplicada + parseFloat(groupJson[i][j].ZregeHistBiapli);
              }
              item.ZregeImporte = 0;
              item._factAcumulada = parseFloat(_factAcumulada).toFixed(2);
              item._BASEREGEAplicada = parseFloat(_BASEREGEAplicada).toFixed(2);
              item._zregeproc = "SI";

              /* _BASEREGEPropuesta
               _diferencia*/
              tableMonitor.push(item);
            }

            var _baseREGEAcumulada = 0;
            for (var soc in this.socReceptoras) {
              for (var i in tableMonitor) {
                if (tableMonitor[i].ZsocReceptora === this.socReceptoras[soc]) {
                  _baseREGEAcumulada = _baseREGEAcumulada + parseFloat(tableMonitor[i]._BASEREGEAplicada);
                }
              }
              for (var i in tableMonitor) {
                if (tableMonitor[i].ZsocReceptora === this.socReceptoras[soc]) {
                  tableMonitor[i]._baseREGEAcumulada = parseFloat(_baseREGEAcumulada).toFixed(2);
                }
              }
            }
            for (var i in tableMonitor) {
              Utils._recalcularItemReg(tableMonitor[i], tableMonitor, 0, 0);
            }
            if (tableMonitor.length > 1) {
              var biIguales = 1;
              for (var i = 1; i < tableMonitor.length; i++) {
                if (tableMonitor[i].ZsocReceptora !== tableMonitor[i - 1].ZsocReceptora ||
                  tableMonitor[i].ZsocEmisora !== tableMonitor[i - 1].ZsocEmisora) {
                  tableMonitor[i - 1]._ultimoReg = true;
                  tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
                  biIguales = 1
                  //Ultimo registro
                  if (i == (tableMonitor.length - 1)) {
                    tableMonitor[i]._ultimoReg = true;
                    tableMonitor[i]._visibleBI = true;
                  }
                } else {
                  biIguales = biIguales + 1;
                }
              }
              if (biIguales > 1) {
                tableMonitor[i - 1]._ultimoReg = true;
                tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
                biIguales = 1
              }
            } else if (tableMonitor.length === 1) {
              tableMonitor[0]._ultimoReg = true;
              tableMonitor[0]._visibleBI = true;
            }
            this.jsonModelMonitor.setData(tableMonitor);
            this._oDialogSeleccion.close();
          }.bind(this)
        });
      }
      else {
        //Se debe agregar el filtro de servicios activos
        var zregedate = new Date(this.anio + "/" + this.mes + "/01");
        var aFilterMes = []
        for (var i = parseInt(mes); i > 0; i--) {
          aFilterMes.push(
            new sap.ui.model.Filter({
              filters: [
                new sap.ui.model.Filter("ZregeHistMes", "EQ", this.ajustarCeros(i, 2)),
                new sap.ui.model.Filter("ZregeHistYear", "EQ", this.anio)
              ]
            })
          )
        }
        aFilters.push(new sap.ui.model.Filter("ZregeMes", "EQ", mes));
        aFilterMes.push(new sap.ui.model.Filter("ZregeHistYear", "EQ", null));
        //aFilters.push(new sap.ui.model.Filter({ filters: aFilterMes, and: false }))
        aFilters.push(new sap.ui.model.Filter("ZregeInicio", "LE", new Date(zregedate.getTime() - (zregedate.getTimezoneOffset() * 60 * 1000))))
        aFilters.push(new sap.ui.model.Filter("ZregeFin", "GE", new Date(zregedate.getTime() - (zregedate.getTimezoneOffset() * 60 * 1000))))
        this.getView().getModel().read("/ZCMSD_REGE_MONF", {
          filters: aFilters,
          success: function (oData) {
            oData = oData.results;
            var aMessages = []
            //Conprobar si hay datos
            if (!this.cesvimap) {
              //Comprobar si hay registros para ese año
              var aCurrentYear = [];
              for (var i in oData) {
                if ((oData[i].ZregeHistMes <= this.mes && oData[i].ZregeHistYear === this.anio) || oData[i].ZregeHistYear === "0000") {
                  aCurrentYear.push(oData[i]);
                }
              }
              //Esto significa que no hay datos para ese año, por lo que se copian del año pasado limpiando vlaores
              if (aCurrentYear.length == 0) {
                var groupJson = this.groupBy(oData);
                for (var i in groupJson) {
                  var item = {};
                  var factPend = 0;
                  var baseRegePend = 0;
                  for (var j in groupJson[i]) {
                    if (j == 0) {
                      item = jQuery.extend(true, item, groupJson[i][j]);
                      item.ZregeImporte = 0;
                      item.ZregeHistBiapli = 0;
                      item.ZregeIva = 0;
                      item.ZregeBinr = 0;
                      item.ZregeTextadic = "";
                      item.ZregeEstado = "NO";
                      item.VbelnVa = "";
                      item.VbelnVf = "";
                      item.factPend = 0;
                      item.baseRegePend = 0;
                      item.ZregeBiapli = parseFloat(item.ZregeBiapli).toFixed(2);
                      item.ZregeHistMes = "00"
                      item.ZregeHistYear = "0000"
                      break;
                    }
                  }
                  aCurrentYear.push(item);
                }
              }
              oData = aCurrentYear;

              if (oData.length === 0) {
                var message = this.oResourceBundle.getText("nohayDatosParaPeriodoAnio")
                sap.m.MessageToast.show(message);
                return;
              } else {
                for (var soc in this.socReceptoras) {
                  var found = false;
                  for (var i in oData) {
                    if (oData[i].ZsocReceptora === this.socReceptoras[soc] && oData[i].ZregeMes === this.mes && oData[i].ZregeYear === this.anio) {
                      found = true
                      break;
                    }
                  }
                  if (!found) {
                    var message = {};
                    message.severity = 'W';
                    message.message = this.socReceptoras[soc] + ": " + this.oResourceBundle.getText("nohayDatosParaPeriodoAnio");
                    message.group = ""
                    aMessages.push(message);
                  }
                }
              }
            }
            //Comprobar si no está ya facturado
            var allFact = true;
            for (var soc in this.socReceptoras) {
              var found = false;
              for (var i in oData) {
                if (oData[i].ZregeProc == 'SI' || (oData[i].ZsocReceptora === this.socReceptoras[soc] && oData[i].ZregeHistMes === this.mes && oData[i].ZregeHistYear === this.anio && oData[i].ZregeImporte != 0)) {
                  found = true;
                  var message = {};
                  message.severity = 'W';
                  message.message = this.socReceptoras[soc] + ": " + this.oResourceBundle.getText("yaFacturados");
                  message.group = ""
                  aMessages.push(message);
                  break;
                }
              }
              if (!found) {
                allFact = false;
              } else {
                //Eliminar del odata
                var _odata = []
                for (var i in oData) {
                  if (oData[i].ZsocReceptora !== this.socReceptoras[soc]) {
                    _odata.push(oData[i]);
                  }
                }
                oData = _odata;
              }
            }
            if (allFact) {
              aMessages = [];
              //Ahora se debe mostrar la tabla de historico
              /*var message = this.oResourceBundle.getText("yaFacturados")
              sap.m.MessageToast.show(message);
              return;*/
              var aFilters = [];
              aFilters.push(new sap.ui.model.Filter("ZsocEmisora", "EQ", socEmisora));
              aFilters.push(new sap.ui.model.Filter("ZregeMes", "EQ", this.mes));
              aFilters.push(new sap.ui.model.Filter("ZregeYear", "EQ", this.anio));
              var aFilterSocRec = [];
              for (var i in this.socReceptoras) {
                aFilterSocRec.push(new sap.ui.model.Filter("ZsocReceptora", "EQ", this.socReceptoras[i]))
              }
              aFilters.push(new sap.ui.model.Filter({ filters: aFilterSocRec, and: false }));
              this.getView().getModel().read("/ZCMSD_REGE_HIST2", {
                filters: aFilters,
                success: function (oData) {
                  var tableMonitor = oData.results;
                  tableMonitor.sort((a, b) => {
                    var nameA = a.ZsocEmisora + "|" + a.ZsocReceptora + "|" + a.ZregeBiapli;
                    var nameB = b.ZsocEmisora + "|" + b.ZsocReceptora + "|" + b.ZregeBiapli;
                    if (nameA < nameB) {
                      return -1;
                    }
                    if (nameA > nameB) {
                      return 1;
                    }
                    return 0;
                  });

                  if (tableMonitor.length > 1) {
                    var biIguales = 1;
                    for (var i = 1; i < tableMonitor.length; i++) {
                      if (tableMonitor[i].ZsocReceptora !== tableMonitor[i - 1].ZsocReceptora ||
                        tableMonitor[i].ZsocEmisora !== tableMonitor[i - 1].ZsocEmisora ||
                        tableMonitor[i].ZregeBiapli !== tableMonitor[i - 1].ZregeBiapli) {
                        tableMonitor[i - 1]._ultimoReg = true;
                        tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
                        biIguales = 1
                        //Ultimo registro
                        if (i == (tableMonitor.length - 1)) {
                          tableMonitor[i]._ultimoReg = true;
                          tableMonitor[i]._visibleBI = true;
                        }
                      } else {
                        biIguales = biIguales + 1;
                      }
                    }
                    if (biIguales > 1) {
                      tableMonitor[i - 1]._ultimoReg = true;
                      tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
                      biIguales = 1
                    }
                  } else if (tableMonitor.length === 1) {
                    tableMonitor[0]._ultimoReg = true;
                    tableMonitor[0]._visibleBI = true;
                  }
                  this.getView().getModel("aux").setProperty("/showLog", true);
                  //Se comprueba is hay alguna posicioon que sea facturado en true y que haya fallado la creacion del pedido
                  for (var i in tableMonitor) {
                    if (tableMonitor[i].ZregeEstado === 'SI' && tableMonitor[i].VbelnVa === '') {
                      this.getView().getModel("aux").setProperty("/reprocesable", true);
                    } else if (tableMonitor[i].ZregeEstado === 'NO') {
                      this.getView().getModel("aux").setProperty("/reprocesable", true);
                      tableMonitor[i]._refacturable = true;
                    }
                  }


                  oRouter.navTo("monitorFact");
                  this.jsonModelMonitor.setData(tableMonitor);
                  this._oDialogSeleccion.close();

                }.bind(this)
              });
              return;
            }
            if (aMessages.length !== 0) {
              aMessages = this.armarMensajFront(aMessages);
              this.mostrarMensajes(aMessages, this);
            }
            if (this.cesvimap) {
              oRouter.navTo("cesvimapF1");
              this._oDialogSeleccion.close();
            } else {
              var groupJson = this.groupBy(oData);
              var tableMonitor = [];
              for (var i in groupJson) {
                var item = {};
                var factPend = 0;
                var baseRegePend = 0;
                for (var j in groupJson[i]) {
                  if (j == 0) {
                    item = jQuery.extend(true, item, groupJson[i][j]);
                    item.ZregeImporte = 0;
                    item.ZregeHistBiapli = 0;
                    item.ZregeIva = 0;
                    item.ZregeBinr = 0;
                    item.ZregeTextadic = "";
                    item.ZregeEstado = "NO";
                    item.VbelnVa = "";
                    item.VbelnVf = "";
                  }
                  if (groupJson[i][j].ZregeEstado == 'NO' && groupJson[i][j].ZregeYear == this.anio) {
                    factPend = factPend + parseFloat(groupJson[i][j].ZregeImporte);
                    baseRegePend = baseRegePend + parseFloat(groupJson[i][j].ZregeHistBiapli);
                  }
                }
                item.factPend = parseFloat(factPend).toFixed(2);
                item.baseRegePend = parseFloat(baseRegePend).toFixed(2);
                item.ZregeBiapli = parseFloat(item.ZregeBiapli).toFixed(2);
                tableMonitor.push(item);
              }

              //Hay que ordenar
              tableMonitor.sort((a, b) => {
                var nameA = a.ZsocEmisora + "|" + a.ZsocReceptora + "|" + a.ZregeIdfact + "|" + a.ZregeServicio;
                var nameB = b.ZsocEmisora + "|" + b.ZsocReceptora + "|" + b.ZregeIdfact + "|" + b.ZregeServicio;
                if (nameA < nameB) {
                  return -1;
                }
                if (nameA > nameB) {
                  return 1;
                }
                return 0;
              });

              //Agregamos la logica del pintado de lineas separatorias
              if (tableMonitor.length > 1) {
                var biIguales = 1;
                for (var i = 1; i < tableMonitor.length; i++) {
                  if (tableMonitor[i].ZsocReceptora !== tableMonitor[i - 1].ZsocReceptora ||
                    tableMonitor[i].ZsocEmisora !== tableMonitor[i - 1].ZsocEmisora) {
                    tableMonitor[i - 1]._ultimoReg = true;
                    tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
                    biIguales = 1
                    //Ultimo registro
                    if (i == (tableMonitor.length - 1)) {
                      tableMonitor[i]._ultimoReg = true;
                      tableMonitor[i]._visibleBI = true;
                    }
                  } else {
                    biIguales = biIguales + 1;
                  }
                }
                if (biIguales > 1) {
                  tableMonitor[i - 1]._ultimoReg = true;
                  tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
                  biIguales = 1
                }
              } else if (tableMonitor.length === 1) {
                tableMonitor[0]._ultimoReg = true;
                tableMonitor[0]._visibleBI = true;
              }


              //Para Inmuebles se deben sumar aquelo BIrege que este en no procesados en los meses anteriores
              if (socEmisora === 'Y051') {
                var aFilters = [new sap.ui.model.Filter("zsoc_emisora", "EQ", "Y051"),
                new sap.ui.model.Filter("ZregeProc", "EQ", "NO"),
                new sap.ui.model.Filter("zrege_mes", "LE", this.mes)];
                var aFilterSocRec = [];
                for (var i in this.socReceptoras) {
                  aFilterSocRec.push(new sap.ui.model.Filter("zsoc_receptora", "EQ", this.socReceptoras[i]))
                }
                aFilters.push(new sap.ui.model.Filter({ filters: aFilterSocRec, and: false }));
                this.getView().getModel("bipbi").read("/ZCMSD_REGE_BIPBI", {
                  filters: aFilters,
                  success: function (oData) {
                    oRouter.navTo("monitorFact");
                    for (var i in this.socReceptoras) {
                      var sumBISocRecep = 0;
                      for (var j in oData.results) {
                        if (this.socReceptoras[i] === oData.results[j].zsoc_receptora) {
                          sumBISocRecep = sumBISocRecep + parseFloat(oData.results[j].zrege_bi);
                        }
                      }
                      for (var mon in tableMonitor) {
                        if (this.socReceptoras[i] === tableMonitor[mon].ZsocReceptora) {
                          tableMonitor[mon].ZregeBiapli = parseFloat(sumBISocRecep).toFixed(2);
                        }
                      }
                    }
                    this.jsonModelMonitor.setData(tableMonitor);
                    this._oDialogSeleccion.close();
                  }.bind(this)
                })

              } else {
                oRouter.navTo("monitorFact");
                this.jsonModelMonitor.setData(tableMonitor);
                this._oDialogSeleccion.close();
              }



            }
          }.bind(this),
          error: function () {
            debugger
          }

        })
      }
    },
    readDataRectificacion : function(aFilters,entity){
      this.getView().getModel().read(entity, {
        filters: aFilters,
        success: function (oData) {

          oData.results[oData.results.length - 1]._ultimoReg = true;
          for (var i in oData.results) {
            oData.results[i]._zregeproc = 'NO';
            oData.results[i]._original = true;
            var item = jQuery.extend(true, {}, oData.results[i]);
            item._original = false;
            item.ZregeImporte = 0;
            item.VbelnVf = "";
            item._cloneId = i;
            oData.results.push(item);
          }
          oData.results[oData.results.length - 1]._ultimoReg = true;
          var tableMonitor = oData.results;
          if (tableMonitor.length > 1) {
            var biIguales = 1;
            for (var i = 1; i < tableMonitor.length; i++) {
              if (tableMonitor[i].ZsocReceptora !== tableMonitor[i - 1].ZsocReceptora ||
                tableMonitor[i].ZsocEmisora !== tableMonitor[i - 1].ZsocEmisora ||
                tableMonitor[i].ZregeBiapli !== tableMonitor[i - 1].ZregeBiapli ||
                tableMonitor[i]._original !== tableMonitor[i - 1]._original) {
                tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
                biIguales = 1
                //Ultimo registro
                if (i == (tableMonitor.length - 1)) {
                  tableMonitor[i]._visibleBI = true;
                }
              } else {
                biIguales = biIguales + 1;
              }
            }
            if (biIguales > 1) {
              tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
              biIguales = 1
            }
          } else if (tableMonitor.length === 1) {
            tableMonitor[0]._visibleBI = true;
          }

          this.jsonModelMonitor.setData(oData.results);
          this._oDialogSeleccion.close();
        }.bind(this),
        error: function () {
          debugger
        }

      })
    },
    readDataRectificacionBR : function(aFilters,entity){
      this.getView().getModel().read(entity, {
        filters: aFilters,
        success: function (oData) {
          var tableMonitor = oData.results;
          tableMonitor.sort((a, b) => {
            var nameA = a.ZsocEmisora + "|" + a.ZsocReceptora + "|" + a.ZregeBiapli;
            var nameB = b.ZsocEmisora + "|" + b.ZsocReceptora + "|" + b.ZregeBiapli;
            if (nameA < nameB) {
              return -1;
            }
            if (nameA > nameB) {
              return 1;
            }
            return 0;
          });

          if (tableMonitor.length > 1) {
            var biIguales = 1;
            for (var i = 1; i < tableMonitor.length; i++) {
              if (tableMonitor[i].ZsocReceptora !== tableMonitor[i - 1].ZsocReceptora ||
                tableMonitor[i].ZsocEmisora !== tableMonitor[i - 1].ZsocEmisora ||
                tableMonitor[i].ZregeBiapli !== tableMonitor[i - 1].ZregeBiapli) {
                tableMonitor[i - 1]._ultimoReg = true;
                tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
                biIguales = 1
                //Ultimo registro
                if (i == (tableMonitor.length - 1)) {
                  tableMonitor[i]._ultimoReg = true;
                  tableMonitor[i]._visibleBI = true;
                }
              } else {
                biIguales = biIguales + 1;
              }
            }
            if (biIguales > 1) {
              tableMonitor[i - 1]._ultimoReg = true;
              tableMonitor[i - 1 - parseInt(biIguales / 2)]._visibleBI = true;
              biIguales = 1
            }
          } else if (tableMonitor.length === 1) {
            tableMonitor[0]._ultimoReg = true;
            tableMonitor[0]._visibleBI = true;
          }

          for (var i in tableMonitor) {
            if (tableMonitor[i].ZregeProc == 'NO') {
              Utils._recalcularItem(tableMonitor[i], tableMonitor, 0, 0)

              tableMonitor[i].VbelnVf = "";
            }
            tableMonitor[i]._zregeproc = 'SI';
          }

          this.jsonModelMonitor.setData(oData.results);
          this._oDialogSeleccion.close();
        }.bind(this),
        error: function () {
          debugger
        }

      })
    },
    onCancelarApp: function () {
      var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
      oCrossAppNavigator.toExternal({
        target: {
          shellHash: "#"
        }
      });
    },
    groupBy: function (xs) {
      return xs.reduce(function (rv, x) {
        (rv[x.ZsocEmisora + "|" + x.ZsocReceptora + "|" +
          x.ZregeServicio + "|" + x.ZregeBiapli + "|" +
          x.Matnr + "|" + x.Zcecoemisor + "|" +
          x.Zlnemisor + "|" + x.Zcanalemisor + "|" +
          x.Zcecoreceptor + "|" + x.Zlnreceptor + "|" +
          x.Zcanalreceptor + "|" + x.Zcuentareceptor
        ] ??= []).push(x);
        return rv;
      }, {});
    },
    groupByWithoutBI: function (xs) {
      return xs.reduce(function (rv, x) {
        (rv[x.ZsocEmisora + "|" + x.ZsocReceptora + "|" +
          x.ZregeServicio + "|" + x.ZregeSegreparto + "|" +
          x.Matnr + "|" + x.Zcecoemisor + "|" +
          x.Zlnemisor + "|" + x.Zcanalemisor + "|" +
          x.Zcecoreceptor + "|" + x.Zlnreceptor + "|" +
          x.Zcanalreceptor + "|" + x.Zcuentareceptor
        ] ??= []).push(x);
        return rv;
      }, {});
    },
    ajustarCeros: function (field, length) {
      if (field && field.toString().length < length) {
        var ceros = length - field.toString().length;
        for (var i = 0; i < ceros; i++) {
          field = "0" + field;
        }
      }
      return field;
    },
    armarMensajFront: function (mensaje) {
      var mensajes = [];

      if (mensaje.length) {
        for (var i = 0; i < mensaje.length; i++) {
          mensajes.push({
            "Type": mensaje[i].severity,
            "Message": mensaje[i].message,
            "Group": mensaje[i].group
          });
        }
      }
      return mensajes;
    },
    mostrarMensajes: function (mensajes, thes, callback) {


      /*var mensajes = [{
        "Type": "E",
        "Message": "Mensaje de prueba"
      }];*/

      for (var i = 0; i < mensajes.length; i++) {
        switch (mensajes[i].Type) {
          case "E":
            mensajes[i].Type = "Error";
            break;
          case "S":
            mensajes[i].Type = "Success";
            break;
          case "W":
            mensajes[i].Type = "Warning";
            break;
          case "I":
            mensajes[i].Type = "Information";
            break;
          case "error":
            mensajes[i].Type = "Error";
            break;
          case "success":
            mensajes[i].Type = "Success";
            break;
          case "warning":
            mensajes[i].Type = "Warning";
            break;
          case "info":
            mensajes[i].Type = "Information";
            break;
        }
      }

      var oMessageTemplate = new sap.m.MessageItem({
        type: '{Type}',
        title: '{Message}',
        groupName: '{Group}'
      });

      var oModel = new sap.ui.model.json.JSONModel(mensajes);

      var oBackButton = new sap.m.Button({
        icon: sap.ui.core.IconPool.getIconURI("nav-back"),
        visible: false,
        press: function () {
          thes.oMessageView.navigateBack();
          this.setVisible(false);
        }
      });

      this.oMessageView = new sap.m.MessageView({
        showDetailsPageHeader: false,
        itemSelect: function () {
          oBackButton.setVisible(true);
        },
        items: {
          path: "/",
          template: oMessageTemplate
        },
        groupItems: true
      });

      this.oMessageView.setModel(oModel);

      this.oDialog = new sap.m.Dialog({
        resizable: true,
        content: this.oMessageView,
        beginButton: new sap.m.Button({
          press: function (oEvent) {
            sap.ui.getCore().byId(oEvent.getSource().getParent().getId()).close();
          },
          text: "Close"
        }),
        customHeader: new sap.m.Bar({
          contentMiddle: [
            new sap.m.Text({
              text: "Mensajes"
            })
          ],
          contentLeft: [oBackButton]
        }),
        contentHeight: "50%",
        contentWidth: "50%",
        verticalScrolling: false
      });
      if (callback) {
        this.oDialog.setBeginButton(new sap.m.Button({
          text: this.oResourceBundle.getText("continuar"),
          press: callback.bind(this)
        }))
      }

      this.oMessageView.navigateBack();
      this.oDialog.open();



    }
  });
});