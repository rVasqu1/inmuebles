sap.ui.define([],
	function () {
		"use strict";

		return {
			_recalcularItem: function (oItemSelected, aMonitor, i, total) {
				if (aMonitor[i]) {
					var oItem = aMonitor[i];
					if (oItem.ZsocEmisora == oItemSelected.ZsocEmisora && oItem.ZsocReceptora == oItemSelected.ZsocReceptora && oItem.ZregeBiapli == oItemSelected.ZregeBiapli && oItem._original == oItemSelected._original) {
						total = total + parseFloat(oItem.ZregeImporte);
					}
					total = this._recalcularItem(oItemSelected, aMonitor, i + 1, total);
					if (oItem.ZsocEmisora == oItemSelected.ZsocEmisora && oItem.ZsocReceptora == oItemSelected.ZsocReceptora && oItem.ZregeBiapli == oItemSelected.ZregeBiapli && oItem._original == oItemSelected._original) {
						var ZregeBiapli = oItem.ZregeBiapli;
						//if(total > ZregeBiapli){
						aMonitor[i].ZregeHistBiapli = ((ZregeBiapli / total) * oItem.ZregeImporte).toFixed(2);
						aMonitor[i].ZregeBinr = (parseFloat(oItem.ZregeImporte).toFixed(2) - aMonitor[i].ZregeHistBiapli).toFixed(2);
						//}else{
						//	aMonitor[i].ZregeHistBiapli = (oItem.ZregeImporte).toFixed(2);
						//}
						if(aMonitor[i].ZregeExento !== "EXENTO"){
							aMonitor[i].ZregeIva = (aMonitor[i].ZregeHistBiapli * 0.21).toFixed(2);
						}else{
							aMonitor[i].ZregeIva = 0.00;
							//aMonitor[i].ZregeBinr = 0.00;
						}
					}
					return total;
				}
				else {
					return total;
				}
			},
			_recalcularItemFacturacion: function (oItemSelected, aMonitor, i, total,totalAcumulado) {
				if (aMonitor[i]) {
					var oItem = aMonitor[i];
					if (oItem.ZsocEmisora == oItemSelected.ZsocEmisora && oItem.ZsocReceptora == oItemSelected.ZsocReceptora && oItem.ZregeBiapli == oItemSelected.ZregeBiapli && oItem._original == oItemSelected._original) {
						total = total + (oItem.ZregeEstado== 'NO' ? parseFloat(oItem.ZregeImporte) : ( parseFloat(oItem.ZregeImporte) - parseFloat(oItem.factPend)));
						totalAcumulado = totalAcumulado + parseFloat(oItem.ZregeImporte);
					}
					var sumatorios = this._recalcularItemFacturacion(oItemSelected, aMonitor, i + 1, total,totalAcumulado);
					if (oItem.ZsocEmisora == oItemSelected.ZsocEmisora && oItem.ZsocReceptora == oItemSelected.ZsocReceptora && oItem.ZregeBiapli == oItemSelected.ZregeBiapli && oItem._original == oItemSelected._original) {
						var ZregeBiapli = oItem.ZregeBiapli;
						//if(total > ZregeBiapli){
						aMonitor[i]._ZregeHistBiapliInter = ((ZregeBiapli / sumatorios.total) * (oItem.ZregeEstado== 'NO' ?parseFloat(oItem.ZregeImporte) : (parseFloat(oItem.ZregeImporte) - parseFloat(oItem.factPend)))).toFixed(2);
						aMonitor[i].ZregeHistBiapli = (oItem.ZregeEstado== 'NO'? aMonitor[i]._ZregeHistBiapliInter : (parseFloat(aMonitor[i]._ZregeHistBiapliInter) + parseFloat(aMonitor[i].baseRegePend)).toFixed(2))
						aMonitor[i].ZregeBinr = (parseFloat(oItem.ZregeImporte).toFixed(2) - aMonitor[i].ZregeHistBiapli).toFixed(2);
						//}else{
						//	aMonitor[i].ZregeHistBiapli = (oItem.ZregeImporte).toFixed(2);
						//}
						if(aMonitor[i].ZregeExento !== "EXENTO"){
							aMonitor[i].ZregeIva = (aMonitor[i].ZregeHistBiapli * 0.21).toFixed(2);
						}else{
							aMonitor[i].ZregeIva = 0.00;
							//aMonitor[i].ZregeBinr = 0.00;
						}
					}
					return sumatorios;
				}
				else {
					return {total:total,totalAcumulado:totalAcumulado};
				}
			},
			_recalcularItemReg: function (oItemSelected, aMonitor, i, total) {
				if (aMonitor[i]) {
					var oItem = aMonitor[i];
					if (oItem.ZsocEmisora == oItemSelected.ZsocEmisora && oItem.ZsocReceptora == oItemSelected.ZsocReceptora && oItem._baseREGEAcumulada == oItemSelected._baseREGEAcumulada) {
						total = total + parseFloat(oItem._factAcumulada);
					}
					total = this._recalcularItemReg(oItemSelected, aMonitor, i + 1, total);
					if (oItem.ZsocEmisora == oItemSelected.ZsocEmisora && oItem.ZsocReceptora == oItemSelected.ZsocReceptora && oItem._baseREGEAcumulada == oItemSelected._baseREGEAcumulada) {
						var ZregeBiapli = oItem._baseREGEAcumulada;
						//if(total > ZregeBiapli){
						aMonitor[i]._BASEREGEPropuesta = ((ZregeBiapli / total) * oItem._factAcumulada).toFixed(2);
						aMonitor[i].ZregeBinr = (parseFloat(oItem._factAcumulada).toFixed(2) - aMonitor[i]._BASEREGEPropuesta).toFixed(2);
						//}else{
						//	aMonitor[i].ZregeHistBiapli = (oItem.ZregeImporte).toFixed(2);
						//}
						if(aMonitor[i].ZregeExento !== "EXENTO"){
							aMonitor[i].ZregeIva = (aMonitor[i]._BASEREGEPropuesta * 0.21).toFixed(2);
						}else{
							aMonitor[i].ZregeIva = 0.00;
							//aMonitor[i].ZregeBinr = 0.00;
						}
						aMonitor[i]._diferencia = (aMonitor[i]._BASEREGEAplicada - aMonitor[i]._BASEREGEPropuesta).toFixed(2)
					}
					return total;
				}
				else {
					return total;
				}
			},
			cancelar: function () {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				if (oRouter.getHashChanger().hash) {
					if (window.location.href.indexOf("&/" + oRouter.getHashChanger().hash) > -1) {
						window.location.href = window.location.href.replace("&/" + oRouter.getHashChanger().hash, "");
					} else {
						window.location.href = window.location.href.replace("/" + oRouter.getHashChanger().hash, "");
					}
					window.location.reload();
				}
			},
			formatMounth: function (mounth) {
				var aMounths = ['', 'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio','julio', 'agosto', 'sep', 'oct', 'nov', 'dic'];
				if (mounth !== undefined && this.getView().getModel("i18n").getResourceBundle()) {
					return this.getView().getModel("i18n").getResourceBundle().getText(aMounths[parseInt(mounth)]);
				} else {
					return ""
				}

			}
		};

	});